﻿# OmniAgent 一键打包脚本：
#   1) 编译主程序（net48 单文件）到 publish\OmniAgent.exe
#   2) 构建安装向导（嵌入主程序）到上级目录 OmniAgent-Setup.exe
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ownapp = Split-Path -Parent $root

Write-Host "== 1/2 打包 OmniAgent 主程序 ==" -ForegroundColor Cyan
Get-Process OmniAgent -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500

# net48 + Costura：依赖已压进 exe，无需 publish / 无需自带运行时
dotnet build "$root\OmniAgent.csproj" -c Release `
  -p:DebugType=None -p:DebugSymbols=false `
  --nologo -v q

if ($LASTEXITCODE -ne 0) { Write-Host "主程序打包失败" -ForegroundColor Red; exit 1 }
New-Item -ItemType Directory -Force -Path "$root\publish" | Out-Null
Copy-Item "$root\bin\Release\OmniAgent.exe" "$root\publish\OmniAgent.exe" -Force
$exe = Get-Item "$root\publish\OmniAgent.exe"
Write-Host ("  主程序: {0}  ({1:N0} KB)" -f $exe.FullName, ($exe.Length / 1KB)) -ForegroundColor Green

Write-Host ""
Write-Host "== 2/2 构建安装向导（嵌入主程序）==" -ForegroundColor Cyan
# 安装向导基于 net48（系统自带），只做常规 build 即可，产物就是一个 exe + 内嵌主程序
dotnet build "$root\Setup\Setup.csproj" -c Release --nologo -v q

if ($LASTEXITCODE -ne 0) { Write-Host "安装向导打包失败" -ForegroundColor Red; exit 1 }
Copy-Item "$root\Setup\bin\Release\OmniAgent-Setup.exe" "$ownapp\OmniAgent-Setup.exe" -Force
$setup = Get-Item "$ownapp\OmniAgent-Setup.exe"
Write-Host ("  安装包: {0}  ({1:N1} MB)" -f $setup.FullName, ($setup.Length / 1MB)) -ForegroundColor Green

Write-Host ""
Write-Host "完成：安装包已生成在 ownapp 目录，用户双击即可选择目录安装并自动创建桌面/开始菜单快捷方式。" -ForegroundColor Green
