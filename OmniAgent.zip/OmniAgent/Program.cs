using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using OmniAgent.Core;

namespace OmniAgent;

static class Program
{
    [STAThread]
    static async Task<int> Main(string[] args)
    {
        // WinExe 无控制台时 net48 会抛 IOException（.NET 10 不抛），加保护
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        if (args.Length > 0 && args[0] == "--probe")
            return await Probe.RunAsync(args);
        if (args.Length > 0 && args[0] == "--discover")
            return await Probe.DiscoverAsync(args);
        if (args.Length > 0 && args[0] == "--selftest")
            return await SelfTest.RunAsync(args);
        if (args.Length > 0 && args[0] == "--integrationtest")
            return await IntegrationTest.RunAsync(args);
        if (args.Length > 0 && args[0] == "--uipaint")
            return UiPaintTest.Run();
        if (args.Length > 0 && args[0] == "--uitest")
            return UiTest.Run();
        if (args.Length > 0 && args[0] == "--layoutdump")
            return LayoutDump.Run(args);
        if (args.Length >= 3 && args[0] == "--capture")
            return CaptureTool.Run(args[1], args[2]);

        // GUI 模式
        for (int i = 0; i < args.Length - 1; i++)
        {
            if (args[i] == "--basedir" && !string.IsNullOrWhiteSpace(args[i + 1]))
                AppSettings.BaseDirOverride = args[i + 1].Trim().Trim('"');
        }
        bool createdNew;
        using var mutex = new Mutex(true, "OmniAgent_SingleInstance_9F3A", out createdNew);
        if (!createdNew)
        {
            MessageBox.Show("OmniAgent 已在运行中。", "OmniAgent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return 0;
        }
        Win32.SetDpiAware();
        try
        {
            var h = Win32.GetConsoleWindow();
            if (h != IntPtr.Zero) Win32.ShowWindow(h, 0); // 隐藏开发期控制台窗口
        }
        catch { }
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
        return 0;
    }
}

/// <summary>
/// 站点选择器探测器：打开调试浏览器，逐个访问站点，检测各选择器是否命中。
/// </summary>
static class Probe
{
    public static async Task<int> DiscoverAsync(string[] args)
    {
        var only = args.Skip(1).FirstOrDefault();
        var bm = new BrowserManager { Port = 9222, ProfileDir = @"C:\_OmniAgent\profile" };
        await bm.LaunchAsync("about:blank");
        foreach (var site in SiteConfig.Defaults())
        {
            if (only != null && !site.Id.Contains(only, StringComparison.OrdinalIgnoreCase)) continue;
            Console.WriteLine($"\n===== 发现 {site.Name} ({site.Id}) =====");
            try
            {
                var t = await bm.FindOrOpenAsync(site);
                using var cdp = await CdpClient.ConnectAsync(t["webSocketDebuggerUrl"]?.GetValue<string>());
                string lastLen = "-1";
                int stable = 0;
                for (int i = 0; i < 60; i++)
                {
                    await Task.Delay(500);
                    var len = await cdp.EvalStringAsync("(document.body&&document.body.innerText||'').length", 8000);
                    if (len != null && len != "0")
                    {
                        if (len == lastLen) { stable++; if (stable >= 3) break; }
                        else { stable = 0; lastLen = len; }
                    }
                }
                var js = BuildDiscoverJs(site);
                var res = await cdp.EvalStringAsync(js, 20000);
                Console.WriteLine(res ?? "<null>");
            }
            catch (Exception ex) { Console.WriteLine($"[!] 失败: {ex.Message}"); }
        }
        Console.WriteLine("\n===== 发现完成 =====");
        return 0;
    }

    static string BuildDiscoverJs(SiteConfig site)
    {
        var input = JsonSerializer.Serialize(site.InputSel);
        return $$"""
(function(){
  var inpSels = {{input}};
  var el = null, matchedSel = null;
  for (var i=0;i<inpSels.length && !el;i++){ try{ el = document.querySelector(inpSels[i]); if(el) matchedSel=inpSels[i]; }catch(e){} }
  if(!el) return JSON.stringify({error:'no-input'});
  var out = { inputTag: el.tagName, inputClass: (el.className&&el.className.baseVal!==undefined?el.className.baseVal:el.className).toString().slice(0,100), inputId: el.id, matchedSel: matchedSel, nearby: [] };
  var seen = [];
  var node = el;
  for (var level=0; level<=6 && node; level++){
    var items = node.querySelectorAll('button, [role="button"], [aria-label]');
    for (var i=0;i<items.length;i++){
      var b = items[i];
      if (seen.indexOf(b)>=0) continue;
      seen.push(b);
      var r = b.getBoundingClientRect();
      if (r.width<6 && r.height<6) continue;
      out.nearby.push({lv:level, tag:b.tagName,
        cls:((b.className&&b.className.baseVal!==undefined?b.className.baseVal:b.className)||'').toString().slice(0,70),
        al:(b.getAttribute('aria-label')||'').slice(0,40),
        tst:(b.getAttribute('data-testid')||''),
        dis:b.getAttribute('aria-disabled'),
        xy:Math.round(r.x)+','+Math.round(r.y)});
    }
    node = node.parentElement;
  }
  var td = [];
  document.querySelectorAll('[data-testid]').forEach(function(x){
    var v = x.getAttribute('data-testid');
    if(/send|stop|submit|compose/i.test(v)) td.push(v+'|'+x.tagName+'|'+(x.getAttribute('aria-disabled')||'')+'|'+(x.getAttribute('aria-label')||''));
  });
  out.testids = td.slice(0,25);
  return JSON.stringify(out, null, 1);
})()
""";
    }
    public static async Task<int> RunAsync(string[] args)
    {
        var only = args.Skip(1).FirstOrDefault();
        var baseDir = args.Contains("--dir") && args.Length > Array.IndexOf(args, "--dir") + 1
            ? args[Array.IndexOf(args, "--dir") + 1]
            : @"C:\_OmniAgent";
        var port = 9222;
        var profile = Path.Combine(baseDir, "profile");
        var bm = new BrowserManager { Port = port, ProfileDir = profile };

        Console.WriteLine($"[i] 浏览器: {BrowserManager.FindBrowser()}");
        Console.WriteLine($"[i] 启动调试浏览器 (port={port}, profile={profile}) ...");
        try
        {
            var st = await bm.LaunchAsync("about:blank");
            Console.WriteLine($"[i] 启动结果: {st}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[!] 启动失败: {ex.Message}");
            return 1;
        }

        foreach (var site in SiteConfig.Defaults())
        {
            if (only != null && !site.Id.Contains(only, StringComparison.OrdinalIgnoreCase)) continue;
            Console.WriteLine($"\n===== {site.Name} ({site.Id})  {site.Url} =====");
            try
            {
                var t = await bm.FindOrOpenAsync(site);
                var wsUrl = t["webSocketDebuggerUrl"]?.GetValue<string>();
                using var cdp = await CdpClient.ConnectAsync(wsUrl);
                // 等待页面稳定：bodyText 非空且连续 3 次不变，最长 30 秒
                string lastLen = "-1";
                int stable = 0;
                for (int i = 0; i < 60; i++)
                {
                    await Task.Delay(500);
                    var len = await cdp.EvalStringAsync("(document.body&&document.body.innerText||'').length", 8000);
                    if (len != null && len != "0")
                    {
                        if (len == lastLen) { stable++; if (stable >= 3) break; }
                        else { stable = 0; lastLen = len; }
                    }
                }
                await Task.Delay(3000);
                var js = BuildProbeJs(site);
                var res = await cdp.EvalStringAsync(js, 20000);
                Console.WriteLine(res ?? "<null>");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[!] 失败: {ex.Message}");
            }
        }
        Console.WriteLine("\n===== 探测完成 =====");
        return 0;
    }

    static string BuildProbeJs(SiteConfig site)
    {
        var input = JsonSerializer.Serialize(site.InputSel);
        var send = JsonSerializer.Serialize(site.SendSel);
        var stop = JsonSerializer.Serialize(site.StopSel ?? Array.Empty<string>());
        var ast = JsonSerializer.Serialize(site.AssistantSel);
        var usr = JsonSerializer.Serialize(site.UserSel);
        return $$"""
(function(){
  function qa(sels){ var n=0; for(var i=0;i<sels.length;i++){ try{ n += document.querySelectorAll(sels[i]).length; }catch(e){} } return n; }
  function per(sels){ var out=[]; for(var i=0;i<sels.length;i++){ try{ out.push({s:sels[i], n:document.querySelectorAll(sels[i]).length}); }catch(e){ out.push({s:sels[i], err:1}); } } return out; }
  function first(sels){
    for(var i=0;i<sels.length;i++){
      try{
        var el = document.querySelector(sels[i]);
        if(el){
          return {sel:sels[i], tag:el.tagName, ce:el.getAttribute('contenteditable'),
                  ph:(el.getAttribute('placeholder')||el.getAttribute('aria-label')||'').slice(0,50),
                  vis: !!(el.offsetWidth||el.offsetHeight||el.getClientRects().length)};
        }
      }catch(e){}
    }
    return null;
  }
  var inpSel = {{input}};
  var sendSel = {{send}};
  var stopSel = {{stop}};
  var astSel = {{ast}};
  var usrSel = {{usr}};
  return JSON.stringify({
    title: document.title,
    url: location.href,
    ready: document.readyState,
    inputCount: qa(inpSel),
    inputFirst: first(inpSel),
    inputPer: per(inpSel),
    sendPer: per(sendSel),
    stopPer: per(stopSel),
    assistantPer: per(astSel),
    userPer: per(usrSel),
    fileInputCount: document.querySelectorAll('input[type=file]').length,
    bodySnippet: (document.body?document.body.innerText:'').slice(0,300).replace(/\n+/g,' / ')
  }, null, 1);
})()
""";
    }
}

/// <summary>工具自检：截图/鼠标/命令执行/窗口枚举等本地能力。</summary>
static class SelfTest
{
    public static async Task<int> RunAsync(string[] args)
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        Console.WriteLine("===== OmniAgent 自检 =====");
        try
        {
            var tools = new Tools.ToolExecutor(@"C:\_OmniAgent\work");
            // 1. 截图
            var shot = tools.Screenshot(0, 0, 0, 0);
            Console.WriteLine($"[截图] OK len={shot.Length} 字节");
            // 2. 窗口枚举
            var wins = tools.GetWindowList();
            Console.WriteLine($"[窗口] 枚举到 {wins.Count} 个可见窗口, 前3个:");
            foreach (var w in wins.Take(3)) Console.WriteLine("   " + w);
            // 3. 命令执行
            var cmdOut = await tools.ExecCommandAsync("Write-Output '[命令执行OK] 中文输出测试'; Get-Date -Format 'yyyy-MM-dd HH:mm:ss'");
            Console.WriteLine($"[命令] OK:\n{cmdOut}");
            // 4. 剪贴板
            tools.SetClipboard("自检文本 123");
            Console.WriteLine($"[剪贴板] 写入/读回: {tools.GetClipboard()}");
            Console.WriteLine("===== 自检完成 =====");
            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[!] 自检失败: {ex}");
            return 1;
        }
    }
}

/// <summary>布局转储：打印窗体与全部控件的 Bounds（窗口坐标），用于盲检。</summary>
static class LayoutDump
{
    public static int Run(string[] args)
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        ApplicationConfiguration.Initialize();
        Win32.SetDpiAware();
        var form = new MainForm();
        form.Show();
        Application.DoEvents();
        if (args.Length >= 3 && int.TryParse(args[1], out var dw) && int.TryParse(args[2], out var dh))
        {
            form.Size = new Size(dw, dh);
            Application.DoEvents();
            form.Size = new Size(dw, dh);
            Application.DoEvents();
        }
        var sb = new StringBuilder();
        sb.AppendLine($"FORM Bounds={form.Bounds} Client={form.ClientRectangle} ClientToScreen={form.PointToScreen(Point.Empty)}");
        Dump(form, 0, sb);
        sb.AppendLine("--- SegButton 状态 ---");
        form.UiDumpSegButtons(sb);
        Console.WriteLine(sb.ToString());
        form.Close();
        return 0;
    }

    private static void Dump(Control c, int depth, StringBuilder sb)
    {
        if (depth > 6) return;
        sb.AppendLine($"{new string(' ', depth * 2)}{c.GetType().Name} '{Trunc(c.Text, 30)}' Bounds={c.Bounds} Visible={c.Visible}");
        if (depth < 5)
            foreach (Control ch in c.Controls) Dump(ch, depth + 1, sb);
    }

    private static string Trunc(string s, int n)
        => string.IsNullOrEmpty(s) ? "" : (s.Length <= n ? s : s.Substring(0, n) + "...");
}

/// <summary>窗口截图工具（PrintWindow）：--capture &lt;hwnd&gt; &lt;输出png&gt;。</summary>
static class CaptureTool
{
    public static int Run(string hwndStr, string path)
    {
        try
        {
            Win32.SetDpiAware(); // 物理像素捕获
            var h = new IntPtr(long.Parse(hwndStr));
            if (Win32.IsIconic(h)) Win32.ShowWindow(h, 9); // 最小化则还原
            // 移动到左上角并多次尝试置顶（避免前台锁导致截到别的窗口）
            Win32.GetWindowRect(h, out var wr0);
            int ww = wr0.Right - wr0.Left, wh = wr0.Bottom - wr0.Top;
            Win32.MoveWindow(h, 0, 0, ww, wh, true);
            for (int i = 0; i < 6; i++)
            {
                Win32.SetForegroundWindow(h);
                Thread.Sleep(250);
                if (Win32.GetForegroundWindow() == h) break;
            }
            var fg = Win32.GetForegroundWindow();
            if (fg != h)
            {
                Console.WriteLine($"WARN: 窗口未能置顶 (fg={fg.ToInt64()})，截图可能是其他窗口");
            }
            Thread.Sleep(300);
            Win32.GetWindowRect(h, out var r);
            int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            using var bmp = new System.Drawing.Bitmap(w, ht);
            using (var g = System.Drawing.Graphics.FromImage(bmp))
            {
                g.CopyFromScreen(r.Left, r.Top, 0, 0, new System.Drawing.Size(w, ht));
            }
            bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png);
            Console.WriteLine($"captured {w}x{ht} fg={fg.ToInt64()} -> {path}");
            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine("capture failed: " + ex.Message);
            return 1;
        }
    }
}

/// <summary>控件自绘渲染测试：DrawToBitmap 整个窗体（窗口客户区），排除屏幕截图干扰。</summary>
static class UiPaintTest
{
    public static int Run()
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        ApplicationConfiguration.Initialize();
        Win32.SetDpiAware();
        var form = new MainForm();
        form.Show();
        Application.DoEvents();
        System.Threading.Thread.Sleep(800);
        Application.DoEvents();
        using var bmp = new System.Drawing.Bitmap(form.ClientSize.Width, form.ClientSize.Height);
        form.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, bmp.Width, bmp.Height));
        bmp.Save(@"C:\_OmniAgent\work\uipaint.png", System.Drawing.Imaging.ImageFormat.Png);
        Console.WriteLine($"uipaint saved {bmp.Width}x{bmp.Height}");
        form.Close();
        return 0;
    }
}

/// <summary>UI 自检：创建主窗体，演练气泡流与视图切换，确认无布局异常。</summary>
static class UiTest
{
    public static int Run()
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        ApplicationConfiguration.Initialize();
        Win32.SetDpiAware();
        try
        {
            var form = new MainForm();
            form.Show();
            Application.DoEvents();
            var chat = form.ChatForTest;
            chat.AddUser("UI 测试：这是一个用户任务气泡（右对齐渐变）");
            chat.AddAi("这是 AI 回复气泡。它显示在左侧，带 AI 头行，支持中文与长文本自动换行。");
            chat.AddTool("执行命令", "Write-Output '测试输出'", "测试输出\n第二行输出内容");
            chat.AddSystem("系统提示：这是一条居中说明文字");
            var typing = chat.AddTyping();
            Application.DoEvents();
            chat.RemoveTyping();
            chat.AddAi("任务完成：全部气泡渲染无异常", done: true);
            Application.DoEvents();
            form.UiSwitchView(1); Application.DoEvents();
            form.UiSwitchView(2); Application.DoEvents();
            form.UiSwitchView(0); Application.DoEvents();
            using (var sf = new SelectorForm(new AppSettings()))
            {
                sf.Show(); Application.DoEvents(); sf.Close();
            }
            // 保持窗口 5 秒（供外部 PrintWindow 截取检查渲染）
            for (int i = 0; i < 50; i++) { Application.DoEvents(); Thread.Sleep(100); }
            chat.Clear();
            Application.DoEvents();
            Console.WriteLine("UITEST OK: 气泡流/打字动画/视图切换/清空 全部无异常");
            form.Close();
            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine("UITEST 失败: " + ex);
            return 1;
        }
    }
}

/// <summary>
/// 端到端集成测试：本地 mock 聊天页模拟 AI（自动回复工具标记），
/// 完整验证 AgentLoop 的 注入→发送→等待回复→解析工具→执行→回传→完成 闭环。
/// </summary>
static class IntegrationTest
{
    public static async Task<int> RunAsync(string[] args)
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { }
        Console.WriteLine("===== OmniAgent 集成测试（mock 聊天页）=====");
        var workDir = @"C:\_OmniAgent\work";
        Directory.CreateDirectory(workDir);
        var tag = DateTime.Now.ToString("HHmmss");
        var mockPath = Path.Combine(workDir, $"mock_chat_{tag}.html");
        File.WriteAllText(mockPath, MockHtml, new UTF8Encoding(false));

        var site = new SiteConfig
        {
            Id = "mock", Name = "MockChat",
            Url = new Uri(mockPath).AbsoluteUri, UrlHost = $"mock_chat_{tag}",
            InputSel = new[] { "textarea" }, InputKind = "textarea",
            SendSel = new[] { "#send" },
            StopSel = new[] { "#stopbtn" },
            AssistantSel = new[] { ".assistant-msg" },
            UserSel = new[] { ".user-msg" },
        };
        var bm = new BrowserManager { Port = 9222, ProfileDir = @"C:\_OmniAgent\profile" };
        var tools = new OmniAgent.Tools.ToolExecutor(workDir);
        var loop = new AgentLoop(bm, tools, maxRounds: 15, replyTimeoutSec: 60)
        {
            Log = Console.WriteLine,
            Status = (k, t) => Console.WriteLine($"[状态] {t}"),
        };
        try
        {
            var final = await loop.RunAsync(site, "集成测试任务：执行命令并截图", null);
            Console.WriteLine("\n===== 最终结果 =====");
            Console.WriteLine(final);
            var pass = final.Contains("mock任务完成");
            Console.WriteLine($"\n===== 集成测试 {(pass ? "通过 ✅" : "失败 ❌")} =====");
            return pass ? 0 : 1;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\n[!] 集成测试失败: {ex}");
            return 1;
        }
    }

    private const string MockHtml = """
<!DOCTYPE html><html><head><meta charset="utf-8"><title>MockChat</title></head>
<body>
<div id="msgs"></div>
<div>
  <textarea id="ta" style="width:400px;height:60px"></textarea>
  <button id="send">发送</button>
  <button id="stopbtn" style="display:none">停止</button>
</div>
<script>
function replyFor(v){
  if(v.indexOf('你是运行在')>=0) return '明白，随时可以开始任务。';
  if(v.indexOf('[工具结果')>=0) return '任务完成_star(mock任务完成：命令与截图工具均已执行成功)_任务完成_end';
  return '执行命令_star(Write-Output \'mock工具输出正常\'; Get-Date -Format yyyyMMdd-HHmmss)_执行命令_end\n截图_star(全屏)_截图_end';
}
document.getElementById('send').onclick = function(){
  var v = document.getElementById('ta').value;
  if(!v) return;
  var u = document.createElement('div'); u.className='user-msg'; u.textContent=v;
  document.getElementById('msgs').appendChild(u);
  document.getElementById('ta').value='';
  var a = document.createElement('div'); a.className='assistant-msg'; a.textContent='';
  document.getElementById('msgs').appendChild(a);
  var full = replyFor(v);
  document.getElementById('stopbtn').style.display='inline-block';
  var i = 0;
  var timer = setInterval(function(){
    if(i < full.length){ a.textContent = full.slice(0, i+3); i+=3; }
    else { clearInterval(timer); document.getElementById('stopbtn').style.display='none'; }
  }, 60);
};
</script>
</body></html>
""";
}
