// 全局 using：net48 的 SDK 不自动注入 System.Net.Http
global using System.Net.Http;
global using System.Net.WebSockets;
// net48 兼容层：用于替代 .NET 5+ 才有的 BCL API（行为逐字等价）
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class Compat
{
    public static int Clamp(int value, int min, int max)
        => value < min ? min : (value > max ? max : value);

    /// <summary>等价于 .NET 6 的 Task.WaitAsync(CancellationToken)。</summary>
    public static async Task<T> WaitAsync<T>(Task<T> task, CancellationToken ct)
    {
        if (task.IsCompleted || !ct.CanBeCanceled) return await task.ConfigureAwait(false);
        var tcs = new TaskCompletionSource<bool>();
        using (ct.Register(static s => ((TaskCompletionSource<bool>)s).TrySetResult(true), tcs))
        {
            if (await Task.WhenAny(task, tcs.Task).ConfigureAwait(false) != task)
                throw new OperationCanceledException(ct);
        }
        return await task.ConfigureAwait(false);
    }

    /// <summary>等价于 .NET 6 的 Task.WaitAsync(TimeSpan, CancellationToken)。</summary>
    public static async Task WaitAsync(Task task, TimeSpan timeout, CancellationToken ct)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(timeout);
        if (await Task.WhenAny(task, Task.Delay(-1, cts.Token)).ConfigureAwait(false) != task)
            throw new OperationCanceledException(cts.Token);
        await task.ConfigureAwait(false);
    }

    /// <summary>等价于 .NET 5 的 Process.WaitForExitAsync(CancellationToken)。</summary>
    public static Task WaitForExitAsync(this Process process, CancellationToken ct)
    {
        if (process.HasExited) return Task.CompletedTask;
        var tcs = new TaskCompletionSource<bool>();
        process.EnableRaisingEvents = true;
        process.Exited += (s, e) => tcs.TrySetResult(true);
        if (ct.CanBeCanceled) ct.Register(() => tcs.TrySetCanceled());
        if (process.HasExited) tcs.TrySetResult(true);
        return tcs.Task;
    }

    private const int EM_SETCUEBANNER = 0x1501;

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

    /// <summary>等价于 .NET 5 的 TextBox.PlaceholderText（原生 Cue Banner）。</summary>
    public static void SetPlaceholder(TextBox tb, string text)
    {
        void Apply()
        {
            if (tb.IsHandleCreated) SendMessage(tb.Handle, EM_SETCUEBANNER, (IntPtr)1, text);
        }
        Apply();
        tb.HandleCreated += (s, e) => Apply();
    }
}

/// <summary>等价于 net10 源生成器产出的 ApplicationConfiguration.Initialize()。</summary>
internal static class ApplicationConfiguration
{
    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    public static void Initialize()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try { SetProcessDPIAware(); } catch { }
    }
}
