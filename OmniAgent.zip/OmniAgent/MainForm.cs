using System.Text.Json;
using OmniAgent.Core;
using OmniAgent.Tools;
using OmniAgent.Ui;

namespace OmniAgent;

public class MainForm : Form
{
    private readonly AppSettings _settings;
    private readonly BrowserManager _bm;
    private ToolExecutor _tools;
    private CancellationTokenSource _cts;
    private List<string> _taskFiles = new();
    private IntPtr _embedHwnd = IntPtr.Zero;
    private long _embedStyle;
    private readonly System.Windows.Forms.Timer _embedTimer;
    private readonly System.Windows.Forms.Timer _dotTimer = new() { Interval = 600 };
    private bool _dotPulse;
    private AiMessage _lastAi;
    private string _lastAiText = "";
    private int _round;
    private int _logLen;

    // 控件
    private ComboBox cbSite;
    private Label lblDot;
    private SegButton segChat, segBrowser, segLog;
    private Button btnClear, btnOpenSite, btnSettings;
    private Panel viewChat, viewBrowser, viewLog;
    private ChatPanel chat;
    private RichTextBox rtxLog;
    private Panel panelEmbed;
    private CheckBox chkEmbed;
    private Label lblEmbedHint;
    private TextBox txtTask;
    private Button btnAttach, btnSend, btnStop, btnWorkdir;
    private Label lblFiles, lblStatus, lblRound;

    public MainForm()
    {
        _settings = AppSettings.Load();
        _bm = new BrowserManager { Port = _settings.Port, ProfileDir = _settings.ProfileDir, BrowserExe = _settings.BrowserExe };
        _tools = new ToolExecutor(_settings.WorkDir);
        BuildUi();
        _dotTimer.Tick += (s, e) =>
        {
            _dotPulse = !_dotPulse;
            lblDot.ForeColor = _dotPulse ? Theme.Warn : Color.FromArgb(120, 88, 26);
        };
        _embedTimer = new System.Windows.Forms.Timer { Interval = 1000 };
        _embedTimer.Tick += (s, e) => EmbedTick();
        Log("OmniAgent 已就绪");
        Log($"工作目录: {_settings.WorkDir}");
        Log("步骤：① 选平台 → ② [打开站点登录] 登录账号（一次即可）→ ③ 输入任务 → ④ 开始任务");
    }

    // ═══════════ UI 构建 ═══════════

    private void BuildUi()
    {
        Text = "OmniAgent · 全能网页智能体";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1120, 800);
        MinimumSize = new Size(940, 660);
        BackColor = Theme.Bg;
        Font = Theme.UiFont;
        Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        // 进程已 SetProcessDPIAware，用物理像素精确布局
        AutoScaleMode = AutoScaleMode.None;
        Win32.ApplyDarkMode(this);

        // ── 顶栏 ──
        var header = new Panel { Dock = DockStyle.Top, Height = 68, BackColor = Theme.Bar };
        header.Paint += (s, e) =>
        {
            using var b = new System.Drawing.Drawing2D.LinearGradientBrush(
                new Rectangle(0, 0, Math.Max(1, header.Width), 2),
                Theme.Accent, Theme.Pink, 0f);
            e.Graphics.FillRectangle(b, 0, 0, header.Width, 2);
        };
        lblDot = new Label
        {
            Text = "●",
            AutoSize = true,
            Font = new Font("Microsoft YaHei UI", 10f),
            ForeColor = Theme.Success,
            Location = new Point(20, 28),
        };
        header.Controls.Add(lblDot);
        var title = new Label
        {
            Text = "OmniAgent",
            AutoSize = true,
            Font = Theme.TitleFont,
            ForeColor = Theme.Text,
            Location = new Point(44, 6),
        };
        header.Controls.Add(title);
        var subtitle = new Label
        {
            Text = "网页 AI 智能体 · 让 AI 操控你的电脑",
            AutoSize = true,
            Font = Theme.SmallFont,
            ForeColor = Theme.Dim,
            Location = new Point(46, 42),
        };
        header.Controls.Add(subtitle);

        btnOpenSite = MakeGhost("🌐 打开站点登录", AnchorStyles.Top | AnchorStyles.Right);
        btnSettings = MakeGhost("⚙ 高级设置", AnchorStyles.Top | AnchorStyles.Right);
        btnWorkdir = MakeGhost("📁 工作目录", AnchorStyles.Top | AnchorStyles.Right);
        var tip = new ToolTip { InitialDelay = 400 };
        tip.SetToolTip(btnWorkdir, "选择 AI 的工作目录（截图/脚本/文件默认存放处）\n当前: " + _settings.WorkDir);
        cbSite = new DarkComboBox
        {
            Width = 150,
            Height = 32,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Location = new Point(ClientSize.Width - 150 - 20, 18),
        };
        cbSite.Items.AddRange(_settings.Sites.ToArray());
        cbSite.SelectedIndex = Math.Max(0, _settings.Sites.FindIndex(s => s.Id == "deepseek"));
        header.Controls.Add(cbSite);
        header.Controls.Add(btnOpenSite);
        header.Controls.Add(btnSettings);
        header.Controls.Add(btnWorkdir);
        header.Resize += (s, e) =>
        {
            cbSite.Location = new Point(header.ClientSize.Width - 150 - 20, 20);
            btnSettings.Location = new Point(header.ClientSize.Width - 150 - 20 - 12 - btnSettings.Width, 18);
            btnOpenSite.Location = new Point(header.ClientSize.Width - 150 - 20 - 12 - btnSettings.Width - 12 - btnOpenSite.Width, 18);
            btnWorkdir.Location = new Point(header.ClientSize.Width - 150 - 20 - 12 - btnSettings.Width - 12 - btnOpenSite.Width - 12 - btnWorkdir.Width, 18);
        };

        // ── 视图切换条 ──
        var switcher = new Panel { Dock = DockStyle.Top, Height = 40, BackColor = Theme.Bar };
        segChat = MakeSeg("💬 对话");
        segBrowser = MakeSeg("🌐 浏览器");
        segLog = MakeSeg("📋 运行日志");
        segChat.Selected = true;
        var segFlow = new FlowLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Location = new Point(12, 4),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Theme.Bar,
        };
        segFlow.Controls.Add(segChat);
        segFlow.Controls.Add(segBrowser);
        segFlow.Controls.Add(segLog);
        switcher.Controls.Add(segFlow);
        // 布局/尺寸变化时强制重绘，避免子控件移动后旧像素残留（"重影"）
        segFlow.Layout += (s, e) => segFlow.Invalidate();
        switcher.Layout += (s, e) => switcher.Invalidate();
        switcher.Resize += (s, e) => switcher.Invalidate();
        btnClear = MakeGhost("🗑 清空对话", AnchorStyles.Top | AnchorStyles.Right);
        btnClear.Height = 28;
        btnClear.Location = new Point(switcher.ClientSize.Width - btnClear.Width - 14, 5);
        switcher.Controls.Add(btnClear);
        switcher.Resize += (s, e) => btnClear.Location = new Point(switcher.ClientSize.Width - btnClear.Width - 14, 5);

        segChat.Click += (s, e) => SwitchView(0);
        segBrowser.Click += (s, e) => SwitchView(1);
        segLog.Click += (s, e) => SwitchView(2);
        btnClear.Click += (s, e) => chat.Clear();

        // ── 三个视图 ──
        viewChat = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Bg };
        chat = new ChatPanel { Dock = DockStyle.Fill };
        chat.SuggestionClicked += s => { txtTask.Text = s; txtTask.Focus(); };
        chat.WelcomeCaption = $"已支持 {_settings.Sites.Count} 个网页 AI 平台 · 零 API 成本 · 免安装免配置";
        viewChat.Controls.Add(chat);

        viewBrowser = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Bg };
        var embedBar = new Panel { Dock = DockStyle.Top, Height = 40, BackColor = Theme.Bar };
        chkEmbed = new CheckBox
        {
            Text = "嵌入浏览器窗口",
            AutoSize = true,
            ForeColor = Theme.Text,
            Font = Theme.UiFont,
            Location = new Point(14, 10),
            Checked = _settings.Embed,
        };
        lblEmbedHint = new Label
        {
            Text = "未嵌入：浏览器在独立窗口。勾选后，调试浏览器窗口会显示在下方区域。",
            AutoSize = true,
            ForeColor = Theme.Dim,
            Font = Theme.SmallFont,
            Location = new Point(170, 13),
        };
        embedBar.Controls.Add(chkEmbed);
        embedBar.Controls.Add(lblEmbedHint);
        viewBrowser.Controls.Add(embedBar);
        panelEmbed = new Panel { Dock = DockStyle.Fill, BackColor = Color.Black };
        panelEmbed.Resize += (s, e) => ResizeEmbed();
        viewBrowser.Controls.Add(panelEmbed);
        chkEmbed.CheckedChanged += (s, e) =>
        {
            if (chkEmbed.Checked)
            {
                lblEmbedHint.Text = "正在查找调试浏览器窗口…（请确保浏览器已启动）";
                if (_embedHwnd == IntPtr.Zero) _embedTimer.Start();
            }
            else
            {
                _embedTimer.Stop();
                StopEmbed();
                lblEmbedHint.Text = "未嵌入：浏览器在独立窗口。勾选后，调试浏览器窗口会显示在下方区域。";
            }
        };

        viewLog = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Bg };
        rtxLog = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BackColor = Theme.CodeBg,
            ForeColor = Color.FromArgb(198, 204, 216),
            Font = Theme.MonoFont,
            BorderStyle = BorderStyle.None,
        };
        viewLog.Controls.Add(rtxLog);

        // ── 底部输入条 ──
        var inputBar = new Panel { Dock = DockStyle.Bottom, Height = 104, BackColor = Theme.Bar };
        var inputWrap = new RoundedPanel
        {
            Fill = Theme.Panel,
            BorderCol = Theme.Border,
            Radius = 16,
            Location = new Point(14, 10),
            Height = 58,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
        };
        txtTask = new TextBox
        {
            Multiline = true,
            BorderStyle = BorderStyle.None,
            BackColor = Theme.Panel,
            ForeColor = Theme.Text,
            Font = new Font("Microsoft YaHei UI", 10.5f),
            ScrollBars = ScrollBars.None,
            WordWrap = true,
            AcceptsReturn = true,
            Location = new Point(12, 9),
            Size = new Size(200, 40),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
        };
        Compat.SetPlaceholder(txtTask, "输入任务，例如：帮我把桌面整理一下，图片都移到 D:\\图片备份 ……（Ctrl+Enter 开始）");
        // 发送按钮并入输入框（ChatGPT 式圆形按钮）
        btnSend = new AccentButton
        {
            Text = "➤",
            Width = 44,
            Height = 44,
            Radius = 22,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
        };
        inputWrap.Controls.Add(txtTask);
        inputWrap.Controls.Add(btnSend);
        inputWrap.Resize += (s, e) =>
        {
            btnSend.Location = new Point(inputWrap.ClientSize.Width - 44 - 8, (inputWrap.Height - 44) / 2);
            txtTask.Width = inputWrap.ClientSize.Width - 44 - 28;
        };
        txtTask.GotFocus += (s, e) => { inputWrap.BorderCol = Theme.Accent; inputWrap.Invalidate(); };
        txtTask.LostFocus += (s, e) => { inputWrap.BorderCol = Theme.Border; inputWrap.Invalidate(); };
        txtTask.KeyDown += (s, e) =>
        {
            if (e.Control && e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; StartTask(); }
        };
        inputBar.Controls.Add(inputWrap);

        // 第二行：附加文件（左）+ 急停（右，运行时显示）
        btnAttach = MakeGhost("📎 附加文件", AnchorStyles.Top | AnchorStyles.Left);
        btnAttach.Height = 28;
        btnAttach.Location = new Point(14, 74);
        lblFiles = new Label { Text = "", AutoSize = true, ForeColor = Theme.Dim, Font = Theme.SmallFont, Location = new Point(150, 80) };
        btnStop = new AccentButton
        {
            Text = "■ 急停",
            Width = 92,
            Height = 28,
            Radius = 10,
            Base1 = Theme.Danger,
            Base2 = Color.FromArgb(200, 60, 90),
            Visible = false,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
        };
        inputBar.Controls.Add(btnAttach);
        inputBar.Controls.Add(lblFiles);
        inputBar.Controls.Add(btnStop);

        void RelayoutInput()
        {
            inputWrap.Width = inputBar.ClientSize.Width - 28;
            var y2 = inputWrap.Bottom + 6;
            btnAttach.Location = new Point(14, y2);
            lblFiles.Location = new Point(150, y2 + 4);
            btnStop.Location = new Point(inputBar.ClientSize.Width - 92 - 14, y2);
        }
        inputBar.Resize += (s, e) => RelayoutInput();

        // 输入自动增高（1~4 行）
        txtTask.TextChanged += (s, e) =>
        {
            int lines = Math.Max(1, txtTask.GetLineFromCharIndex(txtTask.TextLength) + 1);
            int target = Compat.Clamp(34 + lines * 22, 58, 132);
            if (target != inputWrap.Height)
            {
                inputWrap.Height = target;
                txtTask.Height = target - 18;
                inputBar.Height = target + 56;
                RelayoutInput();
            }
        };

        // ── 状态栏 ──
        var statusBar = new Panel { Dock = DockStyle.Bottom, Height = 26, BackColor = Theme.Bar };
        lblStatus = new Label
        {
            Text = "就绪",
            AutoSize = true,
            ForeColor = Theme.Dim,
            Font = Theme.SmallFont,
            Location = new Point(14, 5),
        };
        lblRound = new Label
        {
            Text = "",
            AutoSize = true,
            ForeColor = Theme.Dim,
            Font = Theme.SmallFont,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Location = new Point(statusBar.ClientSize.Width - 160, 5),
        };
        statusBar.Controls.Add(lblStatus);
        statusBar.Controls.Add(lblRound);
        statusBar.Resize += (s, e) => lblRound.Location = new Point(statusBar.ClientSize.Width - 160, 5);

        // 组装（注意：WinForms 停靠顺序 = 添加顺序的逆序，最后添加的先贴边）
        // 期望（上→下）：header → switcher → center → inputBar → statusBar(最底)
        var center = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Bg };
        center.Controls.Add(viewLog);
        center.Controls.Add(viewBrowser);
        center.Controls.Add(viewChat);
        viewChat.BringToFront();
        Controls.Add(center);
        Controls.Add(switcher);   // 先加 switcher，后加 header → header 停靠在最顶
        Controls.Add(header);
        Controls.Add(inputBar);
        Controls.Add(statusBar);

        // ── 事件 ──
        btnOpenSite.Click += async (s, e) => await OpenSiteAsync();
        btnSettings.Click += (s, e) => OpenSettings();
        btnWorkdir.Click += (s, e) => ChooseWorkDir();
        btnSend.Click += (s, e) => StartTask();
        btnStop.Click += (s, e) =>
        {
            Log("· 急停：正在终止当前任务 …");
            try { _cts?.Cancel(); } catch { }
        };
        btnAttach.Click += (s, e) =>
        {
            using var dlg = new OpenFileDialog { Multiselect = true, Title = "选择要附加给 AI 的文件" };
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _taskFiles.AddRange(dlg.FileNames);
                lblFiles.Text = $"📎 已附加 {_taskFiles.Count} 个文件";
            }
        };
        FormClosing += (s, e) =>
        {
            try { _cts?.Cancel(); } catch { }
            StopEmbed();
            SaveSettings();
        };
        Shown += (s, e) =>
        {
            if (_settings.Embed && _embedHwnd == IntPtr.Zero) _embedTimer.Start();
            // 首帧布局完成后强制全量重绘两次，清除布局期间可能残留的旧像素（防止按钮/文字"重影"）
            BeginInvoke(new Action(() => { Invalidate(true); Update(); }));
            var t = new System.Windows.Forms.Timer { Interval = 250 };
            t.Tick += (s2, e2) =>
            {
                t.Stop();
                t.Dispose();
                Invalidate(true);
                Update();
            };
            t.Start();
        };
    }

    // 供 --uitest 自检使用
    internal ChatPanel ChatForTest => chat;
    internal void UiSwitchView(int i) => SwitchView(i);

    internal void UiDumpSegButtons(System.Text.StringBuilder sb)
    {
        foreach (var b in new[] { segChat, segBrowser, segLog })
            sb.AppendLine($"  SegButton '{b.Text}' Bounds={b.Bounds} Sel={b.Selected} W={b.Width} H={b.Height}");
        sb.AppendLine($"--- 平台列表（共 {cbSite.Items.Count} 个）---");
        foreach (var it in cbSite.Items) sb.AppendLine("  " + it);
    }

    private static SegButton MakeSeg(string text)
        => new()
        {
            Text = text,
            // 不用 AutoSize（Button.AutoSize 按中心缩放会导致重叠），测量后固定宽度
            AutoSize = false,
            Height = 32,
            Width = TextRenderer.MeasureText(text, Theme.UiFont).Width + 30,
            Margin = new Padding(0, 0, 6, 0),
        };

    private static GhostButton MakeGhost(string text, AnchorStyles anchor)
    {
        var w = TextRenderer.MeasureText(text, Theme.UiFont).Width + 30;
        return new GhostButton
        {
            Text = text,
            AutoSize = false,
            Height = 30,
            Width = Math.Max(84, w),
            Anchor = anchor,
        };
    }

    private void SwitchView(int idx)
    {
        segChat.Selected = idx == 0;
        segBrowser.Selected = idx == 1;
        segLog.Selected = idx == 2;
        viewChat.Visible = idx == 0;
        viewBrowser.Visible = idx == 1;
        viewLog.Visible = idx == 2;
        segChat.Invalidate(); segBrowser.Invalidate(); segLog.Invalidate();
    }

    // ═══════════ 日志/状态（线程安全） ═══════════

    public void Log(string msg)
    {
        if (IsDisposed) return;
        if (InvokeRequired)
        {
            try { BeginInvoke(new Action<string>(Log), msg); } catch { }
            return;
        }
        var line = $"[{DateTime.Now:HH:mm:ss}] {msg}";
        rtxLog.AppendText(line + "\n");
        _logLen += line.Length;
        if (_logLen > 400000) { rtxLog.Clear(); _logLen = 0; }
        rtxLog.SelectionStart = rtxLog.TextLength;
        rtxLog.ScrollToCaret();
    }

    public void SetStatus(string text, Color? color = null)
    {
        if (IsDisposed) return;
        if (InvokeRequired)
        {
            try { BeginInvoke(new Action(() => SetStatus(text, color))); } catch { }
            return;
        }
        lblStatus.Text = text;
        lblStatus.ForeColor = color ?? Theme.Dim;
    }

    private void SetDot(Color c) { lblDot.ForeColor = c; }

    // ═══════════ 打开站点 / 设置 ═══════════

    private async Task OpenSiteAsync()
    {
        var site = (SiteConfig)cbSite.SelectedItem;
        Log($"· 打开 {site.Name} …");
        SetStatus($"正在打开 {site.Name} …");
        try
        {
            await _bm.LaunchAsync();
            await _bm.FindOrOpenAsync(site);
            Log($"· {site.Name} 已打开。首次使用请登录账号（登录态会保存在 {_settings.ProfileDir}）。");
            Log("· 之后回到本程序，输入任务点[开始]即可。");
            SetStatus("就绪");
        }
        catch (Exception ex)
        {
            Log("✗ " + ex.Message);
            SetStatus("打开站点失败", Theme.Danger);
        }
    }

    private void OpenSettings()
    {
        using var dlg = new SelectorForm(_settings);
        if (dlg.ShowDialog() == DialogResult.OK)
        {
            // 重新应用设置
            _bm.Port = _settings.Port;
            _bm.ProfileDir = _settings.ProfileDir;
            _bm.BrowserExe = _settings.BrowserExe;
            _tools = new ToolExecutor(_settings.WorkDir);
            cbSite.Items.Clear();
            cbSite.Items.AddRange(_settings.Sites.ToArray());
            cbSite.SelectedIndex = Math.Max(0, _settings.Sites.FindIndex(s => s.Id == ((SiteConfig)cbSite.SelectedItem)?.Id));
            chkEmbed.Checked = _settings.Embed;
            _settings.Save();
            Log("· 设置已保存");
        }
    }

    private void ChooseWorkDir()
    {
        using var dlg = new FolderBrowserDialog
        {
            Description = "选择 AI 的工作目录（截图/命令脚本/文件操作的默认存放处）",
            SelectedPath = Directory.Exists(_settings.WorkDir) ? _settings.WorkDir : _settings.BaseDir,
        };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        _settings.WorkDirOverride = dlg.SelectedPath;
        _settings.Save();
        _tools = new ToolExecutor(_settings.WorkDir);
        Log($"· 工作目录已切换: {_settings.WorkDir}");
        SetStatus($"工作目录: {_settings.WorkDir}", Theme.Dim);
        var tip = new ToolTip { InitialDelay = 400 };
        tip.SetToolTip(btnWorkdir, "当前: " + _settings.WorkDir);
    }

    private void SaveSettings()
    {
        _settings.Embed = chkEmbed.Checked;
        _settings.Save();
    }

    // ═══════════ 开始任务 ═══════════

    private void StartTask()
    {
        if (_cts != null) return;
        var site = (SiteConfig)cbSite.SelectedItem;
        var task = txtTask.Text.Trim();
        if (task.Length == 0)
        {
            SetStatus("请先输入任务描述", Theme.Warn);
            txtTask.Focus();
            return;
        }
        SetStatus("开始任务 …", Theme.Accent);
        SetDot(Theme.Warn);
        _round = 0;
        lblRound.Text = "";
        _lastAi = null;
        _lastAiText = "";
        chat.AddUser(task);
        if (_taskFiles.Count > 0)
        {
            var names = string.Join("、", _taskFiles.Select(f => Path.GetFileName(f)).Take(4));
            if (_taskFiles.Count > 4) names += $" 等 {_taskFiles.Count} 个";
            chat.AddSystem($"📎 已附加文件：{names}");
        }
        txtTask.Text = "";
        SetBusy(true);
        _cts = new CancellationTokenSource();
        var files = _taskFiles.ToArray();
        _taskFiles.Clear();
        lblFiles.Text = "";
        var loop = new AgentLoop(_bm, _tools, _settings.MaxRounds, _settings.ReplyTimeoutSec)
        {
            Log = Log,
            Status = (k, t) => SetStatus(t, Theme.Accent),
            Reply = OnReply,
            Waiting = OnWaiting,
            ToolFinished = OnToolFinished,
            Ct = _cts.Token,
        };
        _ = Task.Run(async () =>
        {
            try
            {
                var result = await loop.RunAsync(site, task, files);
                var done = loop.LastWasDone;
                BeginInvoke(new Action(() =>
                {
                    if (!string.IsNullOrEmpty(result))
                    {
                        if (_lastAi != null && result == _lastAiText)
                            chat.SetAiText(_lastAi, _lastAi.Text, done: done);
                        else
                            chat.AddAi(result, done: done);
                    }
                    SetStatus(done ? "任务完成 ✓" : "任务结束", done ? Theme.Success : Theme.Dim);
                    SetDot(Theme.Success);
                }));
            }
            catch (OperationCanceledException)
            {
                Log("· 任务已停止（用户急停）");
                BeginInvoke(new Action(() => SetStatus("已急停", Theme.Warn)));
            }
            catch (AgentException ex)
            {
                Log("✗ " + ex.Message);
                BeginInvoke(new Action(() =>
                {
                    chat.AddSystem("⚠ " + ex.Message, Theme.Danger);
                    SetStatus("任务失败", Theme.Danger);
                }));
            }
            catch (Exception ex)
            {
                Log("✗ 异常: " + ex.Message);
                BeginInvoke(new Action(() =>
                {
                    chat.AddSystem("⚠ 发生异常: " + ex.Message, Theme.Danger);
                    SetStatus("发生异常", Theme.Danger);
                }));
            }
            finally
            {
                BeginInvoke(new Action(() =>
                {
                    SetBusy(false);
                    SetDot(Theme.Success);
                }));
                _cts.Dispose();
                _cts = null;
            }
        });
    }

    private void OnWaiting()
    {
        if (IsDisposed) return;
        BeginInvoke(new Action(() => chat.AddTyping()));
    }

    private void OnReply(string text)
    {
        if (IsDisposed) return;
        BeginInvoke(new Action(() =>
        {
            _round++;
            lblRound.Text = $"第 {_round} 轮 · {((SiteConfig)cbSite.SelectedItem)?.Name}";
            chat.RemoveTyping();
            var clean = AgentLoop.CleanText(text);
            if (clean.Length == 0) return;
            _lastAi = chat.AddAi(clean);
            _lastAiText = clean;
        }));
    }

    private void OnToolFinished(string name, string args, string output)
    {
        if (IsDisposed) return;
        BeginInvoke(new Action(() =>
        {
            chat.RemoveTyping();
            chat.AddTool(name, args, output);
        }));
    }

    private void SetBusy(bool busy)
    {
        btnSend.Enabled = !busy;
        btnStop.Visible = busy;
        btnAttach.Enabled = !busy;
        cbSite.Enabled = !busy;
        btnOpenSite.Enabled = !busy;
        btnSettings.Enabled = !busy;
        btnWorkdir.Enabled = !busy;
        btnClear.Enabled = !busy;
        txtTask.ReadOnly = busy;
        segChat.Enabled = !busy;
        segBrowser.Enabled = !busy;
        segLog.Enabled = !busy;
        if (busy) { _dotPulse = false; _dotTimer.Start(); }
        else { _dotTimer.Stop(); SetDot(Theme.Success); }
    }

    // ═══════════ 浏览器窗口嵌入 ═══════════

    private void EmbedTick()
    {
        if (_embedHwnd != IntPtr.Zero) return;
        var h = _bm.FindBrowserWindow(_bm.MainPid);
        if (h == IntPtr.Zero || h == Handle) return;
        _embedHwnd = h;
        _embedStyle = Win32.GetWindowLongPtr(h, Win32.GWL_STYLE);
        Win32.SetParent(h, panelEmbed.Handle);
        var style = _embedStyle & ~(Win32.WS_CAPTION | Win32.WS_THICKFRAME | Win32.WS_SYSMENU | Win32.WS_MINIMIZEBOX | Win32.WS_MAXIMIZEBOX);
        Win32.SetWindowLongPtr(h, Win32.GWL_STYLE, style);
        ResizeEmbed();
        Log("· 浏览器窗口已嵌入本程序");
        BeginInvoke(new Action(() => lblEmbedHint.Text = "已嵌入 ✓ 浏览器窗口显示在下方"));
        _embedTimer.Stop();
    }

    private void ResizeEmbed()
    {
        if (_embedHwnd != IntPtr.Zero && panelEmbed.IsHandleCreated)
            Win32.MoveWindow(_embedHwnd, 0, 0, panelEmbed.ClientSize.Width, panelEmbed.ClientSize.Height, true);
    }

    private void StopEmbed()
    {
        if (_embedHwnd == IntPtr.Zero) return;
        try
        {
            Win32.SetParent(_embedHwnd, IntPtr.Zero);
            Win32.SetWindowLongPtr(_embedHwnd, Win32.GWL_STYLE, _embedStyle);
            Win32.ShowWindow(_embedHwnd, 9);
            Log("· 浏览器窗口已还原");
        }
        catch { }
        _embedHwnd = IntPtr.Zero;
    }
}

/// <summary>高级设置对话框：通用设置 + 站点选择器编辑。</summary>
public class SelectorForm : Form
{
    private readonly AppSettings _settings;
    private readonly DataGridView _grid;
    private NumericUpDown numPort, numRounds, numTimeout;
    private TextBox txtBrowser, txtWorkdir;
    private CheckBox chkNewChat, chkEmbed;

    public SelectorForm(AppSettings settings)
    {
        _settings = settings;
        Text = "高级设置";
        ClientSize = new Size(1220, 660);
        StartPosition = FormStartPosition.CenterParent;
        BackColor = Theme.Bg;
        Font = Theme.UiFont;
        Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        AutoScaleMode = AutoScaleMode.None;
        Win32.ApplyDarkMode(this);

        var top = new Panel { Dock = DockStyle.Top, Height = 150, BackColor = Theme.Bar };
        var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(14, 12, 14, 6), WrapContents = true, BackColor = Theme.Bar };
        void AddLabel(string t) => flow.Controls.Add(new Label { Text = t, AutoSize = true, ForeColor = Theme.Dim, Margin = new Padding(0, 6, 4, 0) });
        void AddSpace(int w) => flow.Controls.Add(new Panel { Width = w, Height = 1, BackColor = Color.Transparent });

        AddLabel("调试端口:");
        numPort = new NumericUpDown { Minimum = 1024, Maximum = 65535, Width = 80, Value = _settings.Port, BackColor = Theme.Panel, ForeColor = Theme.Text };
        flow.Controls.Add(numPort);
        AddSpace(18);
        AddLabel("浏览器:");
        txtBrowser = new TextBox { Width = 300, BackColor = Theme.Panel, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Text = _settings.BrowserExe };
        flow.Controls.Add(txtBrowser);
        flow.Controls.Add(new Label { Text = "（留空=自动检测 Chrome/Edge）", AutoSize = true, ForeColor = Theme.Dim, Margin = new Padding(6, 6, 0, 0) });
        AddSpace(18);
        AddLabel("最大轮数:");
        numRounds = new NumericUpDown { Minimum = 1, Maximum = 200, Width = 70, Value = _settings.MaxRounds, BackColor = Theme.Panel, ForeColor = Theme.Text };
        flow.Controls.Add(numRounds);
        AddSpace(18);
        AddLabel("回复超时(秒):");
        numTimeout = new NumericUpDown { Minimum = 30, Maximum = 3600, Width = 70, Value = _settings.ReplyTimeoutSec, BackColor = Theme.Panel, ForeColor = Theme.Text };
        flow.Controls.Add(numTimeout);
        AddSpace(18);
        chkNewChat = new CheckBox { Text = "开始前新对话", AutoSize = true, ForeColor = Theme.Text, Checked = _settings.NewChat, Margin = new Padding(0, 6, 0, 0) };
        flow.Controls.Add(chkNewChat);
        chkEmbed = new CheckBox { Text = "嵌入浏览器窗口", AutoSize = true, ForeColor = Theme.Text, Checked = _settings.Embed, Margin = new Padding(14, 6, 0, 0) };
        flow.Controls.Add(chkEmbed);

        // 工作目录（换行）
        var lblWd = new Label { Text = "工作目录:", AutoSize = true, ForeColor = Theme.Dim, Margin = new Padding(0, 8, 4, 0) };
        flow.SetFlowBreak(lblWd, true);
        flow.Controls.Add(lblWd);
        txtWorkdir = new TextBox { Width = 430, BackColor = Theme.Panel, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, Text = _settings.WorkDir };
        flow.Controls.Add(txtWorkdir);
        var btnWdBrowse = new GhostButton { Text = "浏览...", AutoSize = false, Width = 84, Height = 26, Margin = new Padding(8, 4, 0, 0) };
        btnWdBrowse.Click += (s, e) =>
        {
            using var fbd = new FolderBrowserDialog
            {
                Description = "选择工作目录",
                SelectedPath = Directory.Exists(txtWorkdir.Text) ? txtWorkdir.Text : _settings.BaseDir,
            };
            if (fbd.ShowDialog() == DialogResult.OK) txtWorkdir.Text = fbd.SelectedPath;
        };
        flow.Controls.Add(btnWdBrowse);
        flow.Controls.Add(new Label { Text = "（截图/脚本/文件操作的默认存放处；清空=安装目录\\work）", AutoSize = true, ForeColor = Theme.Dim, Margin = new Padding(8, 6, 0, 0) });
        top.Controls.Add(flow);

        _grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            AllowUserToAddRows = false,
            RowHeadersVisible = false,
            EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2,
            BackgroundColor = Theme.Bg,
            GridColor = Theme.Border,
            BorderStyle = BorderStyle.None,
            EnableHeadersVisualStyles = false,
            ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = Theme.Bar,
                ForeColor = Theme.Text,
                SelectionBackColor = Theme.Bar,
                Font = Theme.UiFontBold,
            },
            DefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = Theme.Panel,
                ForeColor = Theme.Text,
                SelectionBackColor = Theme.PanelLight,
                SelectionForeColor = Theme.Text,
                Font = Theme.SmallFont,
            },
            RowTemplate = { Height = 26 },
        };
        _grid.Columns.Add("Id", "站点");
        _grid.Columns.Add("Name", "名称");
        _grid.Columns.Add("InputSel", "输入框");
        _grid.Columns.Add("InputKind", "输入类型");
        _grid.Columns.Add("SendSel", "发送按钮");
        _grid.Columns.Add("StopSel", "停止按钮");
        _grid.Columns.Add("AssistantSel", "AI回复");
        _grid.Columns.Add("UserSel", "用户消息");
        _grid.Columns.Add("NewChatUrl", "新对话URL");
        _grid.Columns["Id"].ReadOnly = true;
        _grid.Columns["Name"].ReadOnly = true;
        _grid.Columns["Id"].FillWeight = 55;
        _grid.Columns["Name"].FillWeight = 55;
        _grid.Columns["InputKind"].FillWeight = 60;
        _grid.Columns["NewChatUrl"].FillWeight = 100;
        foreach (var s in _settings.Sites)
        {
            _grid.Rows.Add(s.Id, s.Name,
                JsonSerializer.Serialize(s.InputSel), s.InputKind,
                JsonSerializer.Serialize(s.SendSel), JsonSerializer.Serialize(s.StopSel ?? Array.Empty<string>()),
                JsonSerializer.Serialize(s.AssistantSel), JsonSerializer.Serialize(s.UserSel),
                s.NewChatUrl);
        }

        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 50, BackColor = Theme.Bar };
        var btnSave = new AccentButton { Text = "保存", Width = 96, Height = 32, Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(bottom.ClientSize.Width - 96 - 14, 9) };
        var btnReset = new GhostButton { Text = "恢复默认", AutoSize = false, Width = TextRenderer.MeasureText("恢复默认", Theme.UiFont).Width + 26, Height = 32, Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(bottom.ClientSize.Width - 96 - 100 - 24, 9) };
        var btnCancel = new GhostButton { Text = "取消", AutoSize = false, Width = TextRenderer.MeasureText("取消", Theme.UiFont).Width + 26, Height = 32, Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(bottom.ClientSize.Width - 96 - 100 - 80 - 34, 9) };
        var hint = new Label
        {
            Text = "选择器为 JSON 数组文本；网站改版导致失效时，点主界面[🌐 打开站点登录]后用 F12 找新选择器，在此更新。",
            AutoSize = true,
            ForeColor = Theme.Dim,
            Font = Theme.SmallFont,
            Location = new Point(14, 17),
        };
        bottom.Controls.Add(btnSave);
        bottom.Controls.Add(btnReset);
        bottom.Controls.Add(btnCancel);
        bottom.Controls.Add(hint);
        bottom.Resize += (s, e) =>
        {
            btnSave.Location = new Point(bottom.ClientSize.Width - 96 - 14, 9);
            btnReset.Location = new Point(bottom.ClientSize.Width - 96 - btnReset.Width - 24, 9);
            btnCancel.Location = new Point(bottom.ClientSize.Width - 96 - btnReset.Width - btnCancel.Width - 34, 9);
        };

        btnSave.Click += (s, e) => Save();
        btnReset.Click += (s, e) =>
        {
            if (MessageBox.Show("确定恢复默认选择器与默认设置？", "高级设置", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            _settings.Sites = SiteConfig.Defaults();
            _settings.Port = 9222;
            _settings.BrowserExe = "";
            _settings.MaxRounds = 40;
            _settings.ReplyTimeoutSec = 300;
            _settings.WorkDirOverride = "";
            _settings.NewChat = true;
            _settings.Embed = false;
            _settings.Save();
            DialogResult = DialogResult.OK;
        };
        btnCancel.Click += (s, e) => DialogResult = DialogResult.Cancel;

        Controls.Add(_grid);
        Controls.Add(top);
        Controls.Add(bottom);
    }

    private void Save()
    {
        try
        {
            _settings.Port = (int)numPort.Value;
            _settings.BrowserExe = txtBrowser.Text.Trim();
            _settings.MaxRounds = (int)numRounds.Value;
            _settings.ReplyTimeoutSec = (int)numTimeout.Value;
            _settings.NewChat = chkNewChat.Checked;
            _settings.Embed = chkEmbed.Checked;
            var wd = txtWorkdir.Text.Trim();
            var wdDef = Path.Combine(_settings.BaseDir, "work");
            _settings.WorkDirOverride = (wd.Length > 0 && !string.Equals(wd, wdDef, StringComparison.OrdinalIgnoreCase)) ? wd : "";
            for (int i = 0; i < _grid.Rows.Count; i++)
            {
                var row = _grid.Rows[i];
                var site = _settings.Sites[i];
                site.InputSel = ParseArr(row.Cells["InputSel"].Value?.ToString());
                site.SendSel = ParseArr(row.Cells["SendSel"].Value?.ToString());
                site.StopSel = ParseArr(row.Cells["StopSel"].Value?.ToString());
                site.AssistantSel = ParseArr(row.Cells["AssistantSel"].Value?.ToString());
                site.UserSel = ParseArr(row.Cells["UserSel"].Value?.ToString());
                site.InputKind = (row.Cells["InputKind"].Value?.ToString() ?? "textarea").Trim();
                site.NewChatUrl = row.Cells["NewChatUrl"].Value?.ToString()?.Trim();
            }
            _settings.Save();
            DialogResult = DialogResult.OK;
        }
        catch (Exception ex)
        {
            MessageBox.Show("保存失败: " + ex.Message, "高级设置", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static string[] ParseArr(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return Array.Empty<string>();
        try { return JsonSerializer.Deserialize<string[]>(s) ?? Array.Empty<string>(); }
        catch (Exception ex) { throw new Exception("选择器 JSON 解析失败: " + ex.Message); }
    }
}
