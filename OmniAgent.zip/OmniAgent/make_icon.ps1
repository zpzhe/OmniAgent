# OmniAgent 图标生成器：蓝紫粉渐变圆角底 + 高光 + 对话气泡 + 三色点 + 四角星
$dir = "D:\HuaweiMoveData\Users\lyneli\Desktop\文件\赵培哲爱编程\ownapp\OmniAgent"
Add-Type -AssemblyName System.Drawing

function New-RoundedPath([float]$x, [float]$y, [float]$w, [float]$h, [float]$rad) {
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = $rad * 2
  $p.AddArc($x, $y, $d, $d, 180, 90)
  $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
  $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
  $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
  $p.CloseFigure()
  return $p
}

function Draw-Icon([int]$s) {
  $bmp = [System.Drawing.Bitmap]::new($s, $s, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $u = [float]($s / 512.0)
  $detail = $s -ge 40

  # ---- 背景圆角方形 ----
  $bx0 = [float](8 * $u); $by0 = [float](8 * $u); $bw0 = [float](496 * $u); $bh0 = [float](496 * $u)
  $bgPath = New-RoundedPath $bx0 $by0 $bw0 $bh0 ([float](120 * $u))
  $bgRect = [System.Drawing.RectangleF]::new($bx0, $by0, $bw0, $bh0)
  $c0 = [System.Drawing.Color]::FromArgb(255, 79, 110, 247)
  $c1 = [System.Drawing.Color]::FromArgb(255, 139, 92, 246)
  $c2 = [System.Drawing.Color]::FromArgb(255, 217, 70, 239)
  $lgb = [System.Drawing.Drawing2D.LinearGradientBrush]::new($bgRect, $c0, $c2, 115.0)
  $blend = New-Object System.Drawing.Drawing2D.ColorBlend
  $blend.Positions = [float[]](0.0, 0.55, 1.0)
  $blend.Colors = [System.Drawing.Color[]]($c0, $c1, $c2)
  $lgb.InterpolationColors = $blend
  $g.FillPath($lgb, $bgPath)

  # ---- 顶部高光 ----
  $g.SetClip($bgPath)
  $hiRect = [System.Drawing.RectangleF]::new($bx0, $by0, $bw0, [float]($bh0 * 0.5))
  $hi = [System.Drawing.Drawing2D.LinearGradientBrush]::new($hiRect, [System.Drawing.Color]::FromArgb(66, 255, 255, 255), [System.Drawing.Color]::FromArgb(0, 255, 255, 255), 90.0)
  $g.FillRectangle($hi, $hiRect)
  $g.ResetClip()

  # ---- 白色对话气泡（带尾巴）----
  if ($detail) { $bbw = 320.0; $bbx = 96.0; $bbh = 230.0; $bby = 148.0 }
  else { $bbw = 340.0; $bbx = 86.0; $bbh = 244.0; $bby = 142.0 }
  $bubble = New-RoundedPath ([float]($bbx * $u)) ([float]($bby * $u)) ([float]($bbw * $u)) ([float]($bbh * $u)) ([float](62 * $u))
  $white = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
  $g.FillPath($white, $bubble)
  # 尾巴
  $tail = [System.Drawing.PointF[]]@(
    [System.Drawing.PointF]::new([float](($bbx + 26) * $u), [float](($bby + $bbh - 8) * $u)),
    [System.Drawing.PointF]::new([float](($bbx + 88) * $u), [float](($bby + $bbh - 8) * $u)),
    [System.Drawing.PointF]::new([float](($bbx + 44) * $u), [float](($bby + $bbh + 42) * $u))
  )
  $g.FillPolygon($white, $tail)

  # ---- 三个圆点 ----
  $dy = [float](($bby + $bbh * 0.45) * $u)
  $dd = if ($detail) { [float](36 * $u) } else { [float](44 * $u) }
  $dx1 = [float](($bbx + 58) * $u); $dx2 = [float](($bbx + 128) * $u); $dx3 = [float](($bbx + 198) * $u)
  $b1 = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 59, 130, 246))
  $b2 = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 139, 92, 246))
  $b3 = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 236, 72, 153))
  $g.FillEllipse($b1, $dx1, $dy, $dd, $dd)
  $g.FillEllipse($b2, $dx2, $dy, $dd, $dd)
  $g.FillEllipse($b3, $dx3, $dy, $dd, $dd)

  # ---- 白色四角星（气泡右上角）----
  if ($detail) {
    $cx = [float](($bbx + $bbw - 58) * $u); $cy = [float](($bby + 34) * $u)
    $r1 = [float](34 * $u); $r2 = [float](10 * $u)
    $pts = [System.Drawing.PointF[]]@(
      [System.Drawing.PointF]::new($cx, $cy - $r1),
      [System.Drawing.PointF]::new($cx + $r2, $cy - $r2),
      [System.Drawing.PointF]::new($cx + $r1, $cy),
      [System.Drawing.PointF]::new($cx + $r2, $cy + $r2),
      [System.Drawing.PointF]::new($cx, $cy + $r1),
      [System.Drawing.PointF]::new($cx - $r2, $cy + $r2),
      [System.Drawing.PointF]::new($cx - $r1, $cy),
      [System.Drawing.PointF]::new($cx - $r2, $cy - $r2)
    )
    $g.FillPolygon($white, $pts)
  }

  $g.Dispose()
  return $bmp
}

$sizes = 16, 20, 24, 32, 40, 48, 64, 128, 256
$imgs = @()
foreach ($s in $sizes) {
  $bmp = Draw-Icon $s
  $ms = New-Object System.IO.MemoryStream
  $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
  $imgs += , @($s, $ms.ToArray())
  $bmp.Dispose()
}
$out = New-Object System.IO.MemoryStream
$bw = New-Object System.IO.BinaryWriter($out)
$bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {
  $s = $sizes[$i]; $len = $imgs[$i][1].Length
  $bw.Write([byte]($(if ($s -ge 256) { 0 } else { $s })))
  $bw.Write([byte]($(if ($s -ge 256) { 0 } else { $s })))
  $bw.Write([byte]0); $bw.Write([byte]0)
  $bw.Write([UInt16]1); $bw.Write([UInt16]32)
  $bw.Write([UInt32]$len); $bw.Write([UInt32]$offset)
  $offset += $len
}
foreach ($img in $imgs) { $bw.Write($img[1]) }
$bw.Flush()
[System.IO.File]::WriteAllBytes("$dir\app.ico", $out.ToArray())
Write-Output "icon OK: $((Get-Item "$dir\app.ico").Length) bytes"

# 另存一张 256 母版 PNG 用于像素校验
$bmp256 = Draw-Icon 256
$bmp256.Save("$dir\icon_preview.png", [System.Drawing.Imaging.ImageFormat]::Png)
$bmp256.Dispose()
Write-Output "preview saved"
