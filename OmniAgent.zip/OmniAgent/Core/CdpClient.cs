using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json.Nodes;

namespace OmniAgent.Core;

/// <summary>
/// 极简 CDP (Chrome DevTools Protocol) 客户端：
/// 基于 System.Net.WebSockets.ClientWebSocket，无任何第三方依赖。
/// </summary>
public sealed class CdpClient : IDisposable
{
    private readonly ClientWebSocket _ws;
    private int _id;
    private readonly ConcurrentDictionary<int, TaskCompletionSource<JsonNode>> _pending = new();
    private readonly CancellationTokenSource _cts = new();

    private CdpClient(ClientWebSocket ws)
    {
        _ws = ws;
        _ = Task.Run(ReadLoop);
    }

    public static async Task<CdpClient> ConnectAsync(string wsUrl, CancellationToken ct = default)
    {
        var ws = new ClientWebSocket();
        ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(10);
        try
        {
            await Compat.WaitAsync(ws.ConnectAsync(new Uri(wsUrl), ct), TimeSpan.FromSeconds(10), ct);
        }
        catch
        {
            ws.Dispose();
            throw new Exception("CDP WebSocket 连接失败: " + wsUrl);
        }
        return new CdpClient(ws);
    }

    private async Task ReadLoop()
    {
        var buf = new byte[4 * 1024 * 1024];
        try
        {
            while (_ws.State == WebSocketState.Open)
            {
                using var ms = new MemoryStream();
                WebSocketReceiveResult r;
                do
                {
                    r = await _ws.ReceiveAsync(new ArraySegment<byte>(buf), _cts.Token);
                    if (r.MessageType == WebSocketMessageType.Close) return;
                    ms.Write(buf, 0, r.Count);
                } while (!r.EndOfMessage);

                var text = Encoding.UTF8.GetString(ms.ToArray());
                JsonNode msg;
                try { msg = JsonNode.Parse(text); } catch { continue; }
                if (msg["id"] is JsonValue idv && idv.TryGetValue<int>(out var mid) &&
                    _pending.TryGetValue(mid, out var tcs))
                {
                    tcs.TrySetResult(msg["result"]);
                }
            }
        }
        catch
        {
            // 连接断开：把未完成的请求全部取消
        }
        foreach (var kv in _pending) kv.Value.TrySetResult(null);
    }

    /// <summary>调用 CDP 方法，返回 response.result（失败返回 null）。</summary>
    public async Task<JsonNode> CallAsync(string method, JsonNode parameters = null, int timeoutMs = 30000)
    {
        var id = Interlocked.Increment(ref _id);
        var tcs = new TaskCompletionSource<JsonNode>(TaskCreationOptions.RunContinuationsAsynchronously);
        _pending[id] = tcs;
        var payload = new JsonObject { ["id"] = id, ["method"] = method };
        if (parameters != null) payload["params"] = parameters;
        var bytes = Encoding.UTF8.GetBytes(payload.ToJsonString());
        try
        {
            await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, _cts.Token);
        }
        catch
        {
            _pending.TryRemove(id, out _);
            return null;
        }
        using var timeout = new CancellationTokenSource(timeoutMs);
        try
        {
            return await Compat.WaitAsync(tcs.Task, timeout.Token);
        }
        catch
        {
            return null;
        }
        finally
        {
            _pending.TryRemove(id, out _);
        }
    }

    /// <summary>
    /// Runtime.evaluate 包装：返回表达式结果的 RemoteObject(result.result)。
    /// 表达式异常时返回 null 并把异常文本放入 error。
    /// </summary>
    public async Task<(JsonNode result, string error)> TryEvalAsync(string expression, bool returnByValue = true, int timeoutMs = 30000)
    {
        var r = await CallAsync("Runtime.evaluate", new JsonObject
        {
            ["expression"] = expression,
            ["returnByValue"] = returnByValue,
            ["awaitPromise"] = true,
        }, timeoutMs);
        if (r == null) return (null, "(无响应)");
        if (r["exceptionDetails"] != null)
        {
            string err;
            try { err = r["exceptionDetails"]["exception"]?["description"]?.GetValue<string>() ?? "JS异常"; }
            catch { err = "JS异常"; }
            return (null, err);
        }
        return (r["result"], null);
    }

    public async Task<JsonNode> EvalAsync(string expression, bool returnByValue = true, int timeoutMs = 30000)
        => (await TryEvalAsync(expression, returnByValue, timeoutMs)).result;

    /// <summary>求值并把结果当作字符串返回（对象会序列化为 JSON）。</summary>
    public async Task<string> EvalStringAsync(string expression, int timeoutMs = 30000)
    {
        var r = await EvalAsync(expression, true, timeoutMs);
        if (r == null) return null;
        var v = r["value"];
        if (v == null) return r["description"]?.GetValue<string>();
        if (v is JsonValue)
        {
            var raw = v.ToJsonString();
            if (raw == "null") return null;
            if (raw.StartsWith("\"", StringComparison.Ordinal)) return v.GetValue<string>();
            return raw;
        }
        return v.ToJsonString();
    }

    public async Task<string> GetTitleAsync()
        => await EvalStringAsync("document.title") ?? "";

    public void Dispose()
    {
        try { _cts.Cancel(); } catch { }
        try { _ws.Dispose(); } catch { }
    }
}
