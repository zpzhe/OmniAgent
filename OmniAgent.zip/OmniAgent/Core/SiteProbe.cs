using System.Text.Json;

namespace OmniAgent.Core;

/// <summary>站点 DOM 探测脚本（GUI 自检与命令行探测共用）。</summary>
public static class SiteProbe
{
    /// <summary>生成选择器命中统计 JS。</summary>
    public static string BuildProbeJs(SiteConfig site)
    {
        var input = JsonSerializer.Serialize(site.InputSel);
        var send = JsonSerializer.Serialize(site.SendSel);
        var stop = JsonSerializer.Serialize(site.StopSel ?? Array.Empty<string>());
        var ast = JsonSerializer.Serialize(site.AssistantSel);
        var usr = JsonSerializer.Serialize(site.UserSel);
        return $$"""
(function(){
  function qa(sels){ var n=0; for(var i=0;i<sels.length;i++){ try{ n += document.querySelectorAll(sels[i]).length; }catch(e){} } return n; }
  function per(sels){ var out=[]; for(var i=0;i<sels.length;i++){ try{ out.push({s:sels[i], n:document.querySelectorAll(sels[i]).length}); }catch(e){ out.push({s:sels[i], err:1}); } } return out; }
  function first(sels){
    for(var i=0;i<sels.length;i++){
      try{
        var el = document.querySelector(sels[i]);
        if(el){
          return {sel:sels[i], tag:el.tagName, ce:el.getAttribute('contenteditable'),
                  ph:(el.getAttribute('placeholder')||el.getAttribute('aria-label')||'').slice(0,50),
                  vis: !!(el.offsetWidth||el.offsetHeight||el.getClientRects().length)};
        }
      }catch(e){}
    }
    return null;
  }
  var inpSel = {{input}};
  var sendSel = {{send}};
  var stopSel = {{stop}};
  var astSel = {{ast}};
  var usrSel = {{usr}};
  return JSON.stringify({
    title: document.title,
    url: location.href,
    ready: document.readyState,
    inputCount: qa(inpSel),
    inputFirst: first(inpSel),
    inputPer: per(inpSel),
    sendPer: per(sendSel),
    stopPer: per(stopSel),
    assistantPer: per(astSel),
    userPer: per(usrSel),
    fileInputCount: document.querySelectorAll('input[type=file]').length,
    bodySnippet: (document.body?document.body.innerText:'').slice(0,300).replace(/\n+/g,' / ')
  }, null, 1);
})()
""";
    }

    /// <summary>生成输入框附近按钮发现 JS。</summary>
    public static string BuildDiscoverJs(SiteConfig site)
    {
        var input = JsonSerializer.Serialize(site.InputSel);
        return $$"""
(function(){
  var inpSels = {{input}};
  var el = null, matchedSel = null;
  for (var i=0;i<inpSels.length && !el;i++){ try{ el = document.querySelector(inpSels[i]); if(el) matchedSel=inpSels[i]; }catch(e){} }
  if(!el) return JSON.stringify({error:'no-input'});
  var out = { inputTag: el.tagName, inputClass: (el.className&&el.className.baseVal!==undefined?el.className.baseVal:el.className).toString().slice(0,100), inputId: el.id, matchedSel: matchedSel, nearby: [] };
  var seen = [];
  var node = el;
  for (var level=0; level<=6 && node; level++){
    var items = node.querySelectorAll('button, [role="button"], [aria-label]');
    for (var i=0;i<items.length;i++){
      var b = items[i];
      if (seen.indexOf(b)>=0) continue;
      seen.push(b);
      var r = b.getBoundingClientRect();
      if (r.width<6 && r.height<6) continue;
      out.nearby.push({lv:level, tag:b.tagName,
        cls:((b.className&&b.className.baseVal!==undefined?b.className.baseVal:b.className)||'').toString().slice(0,70),
        al:(b.getAttribute('aria-label')||'').slice(0,40),
        tst:(b.getAttribute('data-testid')||''),
        dis:b.getAttribute('aria-disabled'),
        xy:Math.round(r.x)+','+Math.round(r.y)});
    }
    node = node.parentElement;
  }
  var td = [];
  document.querySelectorAll('[data-testid]').forEach(function(x){
    var v = x.getAttribute('data-testid');
    if(/send|stop|submit|compose/i.test(v)) td.push(v+'|'+x.tagName+'|'+(x.getAttribute('aria-disabled')||'')+'|'+(x.getAttribute('aria-label')||''));
  });
  out.testids = td.slice(0,25);
  return JSON.stringify(out, null, 1);
})()
""";
    }
}
