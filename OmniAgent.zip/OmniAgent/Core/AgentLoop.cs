using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using OmniAgent.Tools;

namespace OmniAgent.Core;

public class AgentException : Exception
{
    public AgentException(string msg) : base(msg) { }
}

/// <summary>代理主循环：驱动网页 AI 完成任务（发送消息 → 等待回复 → 解析工具标记 → 执行 → 回传结果）。</summary>
public class AgentLoop
{
    public Action<string> Log { get; set; }        // 日志
    public Action<string, string> Status { get; set; } // 状态键, 状态文本
    public Action<string> Reply { get; set; }      // AI 最新回复（预览）
    public Action Waiting { get; set; }            // 消息已发出，正在等待 AI 回复（显示打字动画）
    public Action<string, string, string> ToolFinished { get; set; } // 工具执行完成：工具名, 参数, 输出
    public CancellationToken Ct { get; set; }

    private readonly BrowserManager _bm;
    private readonly ToolExecutor _tools;
    private readonly int _maxRounds;
    private readonly int _replyTimeoutSec;

    /// <summary>最后一次循环是否收到了"任务完成"标记。</summary>
    public bool LastWasDone { get; private set; }

    public AgentLoop(BrowserManager bm, ToolExecutor tools, int maxRounds = 40, int replyTimeoutSec = 300)
    {
        _bm = bm;
        _tools = tools;
        _maxRounds = maxRounds;
        _replyTimeoutSec = replyTimeoutSec;
    }

    private void Info(string msg) => Log?.Invoke(msg);
    private void SetStatus(string key, string text) => Status?.Invoke(key, text);

    // ---------- 解析 ----------

    private static readonly Regex ToolRegex = new(
        @"([A-Za-z0-9_\u4e00-\u9fa5]+)_star\((.*?)\)_\1_end",
        RegexOptions.Singleline | RegexOptions.Compiled);

    public static List<(string name, string args, string raw)> ParseTools(string text)
    {
        var list = new List<(string, string, string)>();
        foreach (Match m in ToolRegex.Matches(text ?? ""))
        {
            list.Add((m.Groups[1].Value, m.Groups[2].Value, m.Value));
        }
        return list;
    }

    // ---------- 页面状态 ----------

    private static string StateJs(SiteConfig site)
    {
        var ast = JsonSerializer.Serialize(site.AssistantSel);
        var usr = JsonSerializer.Serialize(site.UserSel);
        var stop = JsonSerializer.Serialize(site.StopSel ?? Array.Empty<string>());
        var inp = JsonSerializer.Serialize(site.InputSel);
        return $$"""
(function(){
  function pick(sels){ var out=[],seen=[]; for(var i=0;i<sels.length;i++){ try{ document.querySelectorAll(sels[i]).forEach(function(el){ if(seen.indexOf(el)<0){seen.push(el);out.push(el);} }); }catch(e){} } return out; }
  function order(els){ els.sort(function(a,b){ var p=a.compareDocumentPosition(b); if(p & Node.DOCUMENT_POSITION_FOLLOWING) return -1; return 1; }); return els; }
  var usrSel = {{usr}};
  var astSel = {{ast}};
  var stopSel = {{stop}};
  var inpSel = {{inp}};
  var users = order(pick(usrSel));
  var asts = order(pick(astSel));
  var last = asts.length ? (asts[asts.length-1].innerText||asts[asts.length-1].textContent||'').trim() : '';
  var stopVisible = false;
  for(var i=0;i<stopSel.length;i++){ try{ var s=document.querySelector(stopSel[i]); if(s && (s.offsetWidth||s.offsetHeight||s.getClientRects().length)) { stopVisible=true; break; } }catch(e){} }
  var inpEmpty = true;
  for(var i=0;i<inpSel.length;i++){ try{
    var t=document.querySelector(inpSel[i]);
    if(t){ var v = t.value!==undefined ? t.value : (t.innerText||t.textContent||''); if(v && v.trim().length>0){ inpEmpty=false; break; } }
  }catch(e){} }
  return JSON.stringify({user:users.length, last:last, stop:stopVisible, inpEmpty:inpEmpty});
})()
""";
    }

    private async Task<(int user, string last, bool stop, bool inpEmpty)> ReadStateAsync(CdpClient cdp, SiteConfig site)
    {
        var s = await cdp.EvalStringAsync(StateJs(site), 15000);
        if (s == null) return (-1, "", false, true);
        try
        {
            var j = JsonNode.Parse(s);
            return (j["user"].GetValue<int>(), j["last"].GetValue<string>(),
                    j["stop"].GetValue<bool>(), j["inpEmpty"].GetValue<bool>());
        }
        catch { return (-1, "", false, true); }
    }

    // ---------- 发送消息 ----------

    private static string InjectJs(SiteConfig site, string message)
    {
        var inp = JsonSerializer.Serialize(site.InputSel);
        var msg = JsonSerializer.Serialize(message);
        var contentEditable = site.IsContentEditable;
        return $$"""
(function(){
  var MSG = {{msg}};
  var INP = {{inp}};
  function pick(sels){ var out=[],seen=[]; for(var i=0;i<sels.length;i++){ try{ document.querySelectorAll(sels[i]).forEach(function(el){ if(seen.indexOf(el)<0){seen.push(el);out.push(el);} }); }catch(e){} } return out; }
  function visible(el){ if(!el) return false; var r=el.getBoundingClientRect(); return r.width>0&&r.height>0; }
  var ta = null;
  var inputs = pick(INP);
  for(var i=0;i<inputs.length;i++){ if(visible(inputs[i])){ ta=inputs[i]; break; } }
  if(!ta) return JSON.stringify({ok:false, err:'no-input'});
  ta.focus();
  var kind = (ta.tagName==='TEXTAREA')?'ta':'ce';
  if(kind==='ta'){
    var proto = window.HTMLTextAreaElement && HTMLTextAreaElement.prototype;
    var setter = proto ? Object.getOwnPropertyDescriptor(proto,'value').set : null;
    if(setter){ setter.call(ta, MSG); } else { ta.value = MSG; }
    ta.dispatchEvent(new Event('input',{bubbles:true}));
    ta.dispatchEvent(new Event('change',{bubbles:true}));
  } else {
    var done=false;
    try { document.execCommand('selectAll',false,null); done = document.execCommand('insertText', false, MSG); } catch(e){}
    var cur = (ta.innerText||ta.textContent||'');
    if(!done || cur.indexOf(MSG.slice(-20))<0){
      try {
        var dt = new DataTransfer();
        dt.setData('text/plain', MSG);
        ta.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));
      } catch(e){}
    }
    cur = (ta.innerText||ta.textContent||'');
  }
  return JSON.stringify({ok:true, kind:kind, len:cur?cur.length:(ta.value||'').length});
})()
""";
    }

    private static string ClickSendJs(SiteConfig site)
    {
        var send = JsonSerializer.Serialize(site.SendSel);
        var inp = JsonSerializer.Serialize(site.InputSel);
        return $$"""
(function(){
  var SEND = {{send}};
  var INP = {{inp}};
  function pick(sels){ var out=[],seen=[]; for(var i=0;i<sels.length;i++){ try{ document.querySelectorAll(sels[i]).forEach(function(el){ if(seen.indexOf(el)<0){seen.push(el);out.push(el);} }); }catch(e){} } return out; }
  function visible(el){ if(!el) return false; var r=el.getBoundingClientRect(); return r.width>0&&r.height>0; }
  var btn = null, via = '';
  var cands = pick(SEND);
  for(var i=0;i<cands.length;i++){ if(visible(cands[i])) { btn=cands[i]; via='selector'; break; } }
  if(!btn){
    var bad = /上传|添加|附件|语音|图片|相机|模式|听写|开启|mic|attach|upload|photo|camera|voice|audio|file|gallery|plus|search/i;
    var inputs = pick(INP);
    var ta = inputs[0];
    var scope = ta || document.body;
    var list = scope.querySelectorAll('button,[role="button"]');
    var best=null, bestX=-1;
    for(var i=0;i<list.length;i++){
      var b=list[i];
      if(!visible(b)) continue;
      var al=(b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'');
      if(bad.test(al)) continue;
      var r=b.getBoundingClientRect();
      var x=r.left+r.width;
      if(x>bestX){ bestX=x; best=b; }
    }
    if(best){ btn=best; via='smart'; }
  }
  if(!btn){
    // Enter 兜底
    var inputs2 = pick(INP);
    var el = null;
    for(var i=0;i<inputs2.length;i++){ if(visible(inputs2[i])){ el=inputs2[i]; break; } }
    if(!el) return JSON.stringify({ok:false, err:'no-send-no-input'});
    el.focus();
    var e = new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true});
    el.dispatchEvent(e);
    return JSON.stringify({ok:true, via:'enter'});
  }
  btn.click();
  return JSON.stringify({ok:true, via:via});
})()
""";
    }

    /// <summary>把文本注入输入框并点击发送。attachFiles 会先通过 file input 挂附件。返回是否成功。</summary>
    private async Task<bool> SendMessageAsync(CdpClient cdp, SiteConfig site, string text, List<string> attachFiles)
    {
        if (attachFiles is { Count: > 0 })
        {
            var ok = await AttachFilesAsync(cdp, site, attachFiles);
            if (!ok) Info("  ⚠ 附件上传失败（继续发送纯文本）");
        }
        var r = await cdp.EvalStringAsync(InjectJs(site, text), 15000);
        Info("  · 注入文本: " + (r ?? "(null)"));
        await Task.Delay(700, Ct);
        var c = await cdp.EvalStringAsync(ClickSendJs(site), 15000);
        Info("  · 点击发送: " + (c ?? "(null)"));
        if (c == null) return false;
        bool sent;
        try { sent = JsonNode.Parse(c)["ok"]?.GetValue<bool>() == true; }
        catch { return false; }
        if (sent) Waiting?.Invoke();
        return sent;
    }

    private async Task<bool> AttachFilesAsync(CdpClient cdp, SiteConfig site, List<string> files)
    {
        var exists = files.Where(File.Exists).ToList();
        if (exists.Count == 0) return false;
        var obj = await cdp.EvalAsync(
            "document.querySelector('input[type=file]')", false, 10000);
        var objectId = obj?["objectId"]?.GetValue<string>();
        if (string.IsNullOrEmpty(objectId))
        {
            Info("  ⚠ 页面无 file input，无法附加文件");
            return false;
        }
        var arr = new JsonArray();
        foreach (var f in exists) arr.Add(f);
        var r = await cdp.CallAsync("DOM.setFileInputFiles", new JsonObject
        {
            ["files"] = arr,
            ["objectId"] = objectId,
        }, 15000);
        if (r == null) return false;
        Info($"  · 已附加 {exists.Count} 个文件");
        await Task.Delay(2500, Ct); // 等待网站处理上传
        return true;
    }

    // ---------- 等待回复 ----------

    /// <summary>发送后等待新回复。返回 (最终文本, 是否超时)。</summary>
    private async Task<(string text, bool timedOut)> WaitReplyAsync(
        CdpClient cdp, SiteConfig site, int baselineUser, string baselineLast, int timeoutSec)
    {
        var deadline = DateTime.UtcNow.AddSeconds(timeoutSec);
        // 阶段 A：等待消息被接受（用户消息数增加 或 输入框被清空）
        var acceptDeadline = DateTime.UtcNow.AddSeconds(25);
        bool accepted = false;
        while (DateTime.UtcNow < acceptDeadline)
        {
            Ct.ThrowIfCancellationRequested();
            var st = await ReadStateAsync(cdp, site);
            if (st.user > baselineUser || (st.user >= 0 && st.inpEmpty)) { accepted = true; break; }
            await Task.Delay(500, Ct);
        }
        if (!accepted)
        {
            Info("  ⚠ 未检测到消息发出（用户消息数未增加），尝试回车兜底");
            await cdp.EvalStringAsync(
                "(function(){var t=document.querySelector('textarea, [contenteditable=\"true\"]'); if(t){t.focus(); t.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));} return 'ok';})()", 8000);
            await Task.Delay(800, Ct);
            var st2 = await ReadStateAsync(cdp, site);
            if (st2.user <= baselineUser && !st2.inpEmpty)
            {
                Info("  ✗ 消息发送失败：请确认页面已登录且输入框可用");
                throw new AgentException("消息发送失败：未检测到用户消息发出。请确认该站点已登录（点[打开站点]登录），且页面输入框正常。");
            }
            baselineLast = st2.last;
        }
        // 阶段 B：轮询最后一条 AI 回复，文本稳定视为完成。
        // 若"停止生成"按钮仍可见，说明可能还在思考/生成，要求更长的稳定时间。
        string cur = baselineLast;
        int stable = 0;
        bool sawNew = false;
        while (DateTime.UtcNow < deadline)
        {
            Ct.ThrowIfCancellationRequested();
            var st = await ReadStateAsync(cdp, site);
            if (st.user < 0)
            {
                // CDP 读取异常：可能页面导航中，稍后重试
                await Task.Delay(800, Ct);
                continue;
            }
            if (!sawNew)
            {
                if (st.last.Length > 0 && st.last != baselineLast)
                {
                    sawNew = true;
                    cur = st.last;
                }
                await Task.Delay(400, Ct);
                continue;
            }
            if (st.last == cur)
            {
                stable++;
                int need = st.stop ? 15 : 6;
                if (stable >= need && st.last.Length > 0) return (st.last, false);
            }
            else
            {
                stable = 0;
                cur = st.last;
            }
            await Task.Delay(400, Ct);
        }
        var final = await ReadStateAsync(cdp, site);
        return (final.last, true);
    }

    // ---------- 工具执行 ----------

    private async Task<(string output, List<string> images)> ExecuteToolAsync(string name, string args)
    {
        var images = new List<string>();
        string output = null;
        var parts = args.Split('|');
        switch (name.ToLower())
        {
            case "执行命令":
            case "cmd":
                output = await _tools.ExecCommandAsync(args);
                break;
            case "运行程序":
            case "run":
                {
                    var exe = parts.Length > 0 ? parts[0].Trim() : "";
                    var p2 = parts.Length > 1 ? parts[1] : "";
                    var to = parts.Length > 2 && int.TryParse(parts[2].Trim(), out var t2) ? t2 * 1000 : 60000;
                    if (exe.Length == 0) output = "[失败] 缺少程序路径";
                    else output = await _tools.ExecProgramAsync(exe, p2, to);
                    break;
                }
            case "截图":
            case "screenshot":
                {
                    int x = 0, y = 0, w = 0, h = 0;
                    var a = args.Trim();
                    if (a.Length > 0 && !a.Equals("全屏"))
                    {
                        var ns = a.Split(new[] { ',', '，', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                                   .Select(s => int.TryParse(s.Trim(), out var v) ? v : -1).ToList();
                        if (ns.Count >= 4 && ns.Take(4).All(v => v >= 0))
                        {
                            x = ns[0]; y = ns[1]; w = ns[2]; h = ns[3];
                        }
                        else output = "[失败] 截图参数格式：留空/全屏 或 x,y,宽,高";
                    }
                    if (w == 0 && h == 0 && output == null)
                    {
                        var path = _tools.SaveScreenshot(x, y, w, h);
                        images.Add(path);
                        output = $"[截图成功] 图片已生成并附在本条消息中（{path}）";
                    }
                    break;
                }
            case "屏幕信息":
            case "screeninfo":
                output = _tools.ScreenInfo();
                break;
            case "鼠标移动":
            case "move":
                {
                    var ns = ParseInts(args, 2);
                    output = ns != null ? _tools.MouseMove(ns[0], ns[1]) : "[失败] 参数: x,y";
                    break;
                }
            case "鼠标点击":
            case "click":
                {
                    var ps = args.Split(new[] { ',', '，' }, StringSplitOptions.RemoveEmptyEntries)
                                  .Select(s => s.Trim()).ToList();
                    if (ps.Count >= 2 && int.TryParse(ps[0], out var cx) && int.TryParse(ps[1], out var cy))
                    {
                        var btn = ps.Count > 2 ? ps[2] : "左键";
                        var clk = ps.Count > 3 && int.TryParse(ps[3], out var cc) ? cc : 1;
                        output = _tools.MouseClick(cx, cy, btn, clk);
                    }
                    else output = "[失败] 参数: x,y,按键,次数";
                    break;
                }
            case "鼠标滚轮":
            case "scroll":
                {
                    var ps = args.Split(new[] { ',', '，' }, StringSplitOptions.RemoveEmptyEntries)
                                  .Select(s => s.Trim()).ToList();
                    if (ps.Count >= 1 && int.TryParse(ps[0], out var amt))
                    {
                        if (ps.Count >= 3 && int.TryParse(ps[1], out var sx) && int.TryParse(ps[2], out var sy))
                            output = _tools.MouseScroll(amt, sx, sy);
                        else output = _tools.MouseScroll(amt);
                    }
                    else output = "[失败] 参数: 格数[,x,y]";
                    break;
                }
            case "鼠标拖拽":
            case "drag":
                {
                    var ns = ParseInts(args, 4);
                    output = ns != null ? _tools.MouseDrag(ns[0], ns[1], ns[2], ns[3]) : "[失败] 参数: x1,y1,x2,y2";
                    break;
                }
            case "键盘按键":
            case "key":
                output = _tools.KeyTap(args.Trim());
                break;
            case "输入文本":
            case "type":
                output = _tools.TypeText(args);
                break;
            case "读取文件":
            case "read":
                output = _tools.ReadFile(args.Trim());
                break;
            case "写入文件":
            case "write":
                {
                    var path = parts.Length > 0 ? parts[0].Trim() : "";
                    var mode = parts.Length > 1 ? parts[1].Trim() : "覆盖";
                    var content = parts.Length > 2 ? string.Join("|", parts.Skip(2)) : "";
                    if (path.Length == 0) output = "[失败] 缺少路径";
                    else output = _tools.WriteFile(path, content, mode);
                    break;
                }
            case "列目录":
            case "ls":
                output = _tools.ListDir(args.Trim());
                break;
            case "文件是否存在":
            case "exists":
                output = _tools.FileExists(args.Trim());
                break;
            case "窗口列表":
            case "windows":
                {
                    var list = _tools.GetWindowList();
                    output = list.Count == 0 ? "(没有可见窗口)" : string.Join("\n", list.Take(80));
                    if (list.Count > 80) output += $"\n...（共 {list.Count} 个，已截断）";
                    break;
                }
            case "窗口操作":
            case "window":
                {
                    var ps = args.Split(new[] { '|', '，', ',' }, 2, StringSplitOptions.RemoveEmptyEntries)
                                  .Select(s => s.Trim()).ToList();
                    if (ps.Count < 2) output = "[失败] 参数: 句柄或标题|动作";
                    else output = _tools.WindowAction(ps[0], ps[1]);
                    break;
                }
            case "剪贴板读取":
            case "clipget":
                output = _tools.GetClipboard();
                break;
            case "剪贴板写入":
            case "clipset":
                output = _tools.SetClipboard(args);
                break;
            case "http访问":
            case "http":
                output = await _tools.HttpGetAsync(args.Trim());
                break;
            case "下载文件":
            case "download":
                {
                    var ps = args.Split(new[] { '|', '，' }, 2, StringSplitOptions.RemoveEmptyEntries)
                                  .Select(s => s.Trim()).ToList();
                    if (ps.Count < 2) output = "[失败] 参数: url|保存路径";
                    else output = await _tools.DownloadFileAsync(ps[0], ps[1]);
                    break;
                }
            case "等待":
            case "wait":
                {
                    output = int.TryParse(args.Trim(), out var ms) ? _tools.Wait(ms) : "[失败] 参数: 毫秒";
                    break;
                }
            case "当前时间":
            case "time":
                output = _tools.GetTime();
                break;
            default:
                output = $"[失败] 未知工具: {name}";
                break;
        }
        return (output, images);
    }

    private static int[] ParseInts(string s, int count)
    {
        var ns = s.Split(new[] { ',', '，', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                  .Select(t => int.TryParse(t.Trim(), out var v) ? v : -1).ToList();
        if (ns.Count < count || ns.Take(count).Any(v => v < 0)) return null;
        return ns.Take(count).ToArray();
    }

    // ---------- 主流程 ----------

    public async Task<string> RunAsync(SiteConfig site, string task, string[] files)
    {
        LastWasDone = false;
        Info($"== 开始任务（平台: {site.Name}）==");
        SetStatus("state", $"连接 {site.Name} ...");

        await _bm.LaunchAsync();
        Info("· 调试浏览器已就绪");
        var target = await _bm.FindOrOpenAsync(site);
        var wsUrl = target["webSocketDebuggerUrl"]?.GetValue<string>();
        using var cdp = await CdpClient.ConnectAsync(wsUrl);
        await cdp.CallAsync("Page.enable");
        await cdp.CallAsync("Page.bringToFront");

        // 新对话
        if (!string.IsNullOrEmpty(site.NewChatUrl))
        {
            await cdp.CallAsync("Page.navigate", new JsonObject { ["url"] = site.NewChatUrl });
            await Task.Delay(2500, Ct);
            // 等待新页面输入框出现（SPA 加载）
            bool inputReady = false;
            for (int i = 0; i < 40; i++)
            {
                var c = await cdp.EvalStringAsync(
                    "(function(){var t=document.querySelector('textarea, [contenteditable=\"true\"]'); return t? 'ok':'none';})()", 10000);
                if (c == "ok") { inputReady = true; break; }
                await Task.Delay(750, Ct);
            }
            Info(inputReady ? "· 已导航到新对话页面" : "· ⚠ 新对话页面输入框尚未出现（页面可能仍在加载）");
        }

        // 登录/输入框检查
        var check = await cdp.EvalStringAsync(
            "(function(){var t=document.querySelector('textarea, [contenteditable=\"true\"]'); return t? 'ok':'none';})()", 15000);
        if (check == null)
            throw new AgentException("无法与页面通信（CDP 求值失败）。请重启浏览器后重试。");
        if (check == "none")
            throw new AgentException($"在 {site.Name} 页面上找不到输入框：可能未登录或需要人机验证。请点[打开站点]完成登录后再开始。");

        int round = 0;
        string lastText = "";

        // 1. 发送系统提示词
        Info("· 发送系统提示词 ...");
        SetStatus("state", "发送系统提示词");
        var (sysU, sysL, _, _) = await ReadStateAsync(cdp, site);
        if (!await SendMessageAsync(cdp, site, SystemPrompt.Build(_tools.WorkDir), null))
            throw new AgentException("系统提示词发送失败");
        var sysReply = await WaitReplyAsync(cdp, site, sysU, sysL, 120);
        Info($"· 系统提示词已送达（AI 已就绪）{(sysReply.timedOut ? "（等待超时，继续）" : "")}");

        // 2. 发送用户任务
        Info("· 发送用户任务 ...");
        SetStatus("state", "发送任务");
        var (u0, l0, _, _) = await ReadStateAsync(cdp, site);
        var attach = files?.Where(File.Exists).ToList();
        if (!await SendMessageAsync(cdp, site, task, attach))
            throw new AgentException("任务消息发送失败");
        var (reply, timedOut) = await WaitReplyAsync(cdp, site, u0, l0, _replyTimeoutSec);
        lastText = reply;

        // 3. 工具循环
        int nudges = 0;
        while (round < _maxRounds)
        {
            round++;
            Ct.ThrowIfCancellationRequested();
            SetStatus("state", $"第 {round} 轮处理中");
            Info($"── 第 {round} 轮 AI 回复（{lastText.Length} 字符）──");
            Reply?.Invoke(lastText);

            var tools = ParseTools(lastText);
            if (tools.Count == 0)
            {
                // 无工具标记：可能已结束或需要引导
                if (lastText.Trim().Length == 0 && nudges < 2)
                {
                    nudges++;
                    Info("· AI 回复为空，发送引导消息");
                    var (uu, lu, _, _) = await ReadStateAsync(cdp, site);
                    if (await SendMessageAsync(cdp, site,
                        "[系统] 你的回复为空。若任务已完成请输出 任务完成_star(总结)_任务完成_end；若需要操作电脑请输出工具标记。", null))
                    {
                        var nudgeReply = await WaitReplyAsync(cdp, site, uu, lu, _replyTimeoutSec);
                        lastText = nudgeReply.text;
                    }
                    continue;
                }
                if (lastText.Trim().Length > 0 && nudges < 2)
                {
                    nudges++;
                    Info("· 回复中无工具标记，发送引导消息");
                    var (uu, lu, _, _) = await ReadStateAsync(cdp, site);
                    if (await SendMessageAsync(cdp, site,
                        "[系统] 收到你的文本回复，但未检测到工具标记。若任务已完成请输出 任务完成_star(总结)_任务完成_end；若还需执行操作请直接输出工具标记（不要用代码块包裹）。", null))
                    {
                        var nudgeReply = await WaitReplyAsync(cdp, site, uu, lu, _replyTimeoutSec);
                        lastText = nudgeReply.text;
                    }
                    continue;
                }
                Info("· 无工具标记且引导次数已用尽，视为任务结束");
                break;
            }

            // 执行工具
            var results = new List<string>();
            var images = new List<string>();
            int idx = 0;
            bool done = false;
            string finalText = null;
            foreach (var (name, args, raw) in tools)
            {
                Ct.ThrowIfCancellationRequested();
                idx++;
                if (name is "任务完成" or "done" or "完成")
                {
                    done = true;
                    LastWasDone = true;
                    finalText = args;
                    Info($"· 收到任务完成标记: {args}");
                    break;
                }
                Info($"· 执行工具 {idx}/{tools.Count}: {name}_star(...)_end");
                SetStatus("state", $"执行工具: {name}");
                try
                {
                    var (outp, imgs) = await ExecuteToolAsync(name, args);
                    results.Add($"[{idx}] {name}_star({Truncate(args, 200)})_end\n输出:\n{outp}");
                    images.AddRange(imgs);
                    ToolFinished?.Invoke(name, Truncate(args, 200), outp);
                }
                catch (Exception ex)
                {
                    results.Add($"[{idx}] {name}\n输出:\n[工具异常] {ex.Message}");
                }
            }
            if (done)
            {
                lastText = finalText ?? "（任务完成，无总结）";
                break;
            }

            // 回传结果
            var msg = $"[工具结果 第{round}轮] 共执行 {results.Count} 个工具：\n\n" + string.Join("\n\n────\n\n", results);
            if (msg.Length > 14000) msg = msg.Substring(0, 14000) + "\n...（结果过长已截断，请用 读取文件 查看完整输出）";
            SetStatus("state", $"回传第 {round} 轮结果");
            Info("· 回传工具结果 ...");
            var (ur, lr, _, _) = await ReadStateAsync(cdp, site);
            var attachList = images.Count > 0 ? images : null;
            if (attachList != null) msg += "\n\n[系统] 本消息附带了截图图片，请查看。";
            if (!await SendMessageAsync(cdp, site, msg, attachList))
            {
                Info("· 结果消息发送失败，尝试重发一次");
                await Task.Delay(2000, Ct);
                if (!await SendMessageAsync(cdp, site, msg, attachList))
                    throw new AgentException("工具结果消息发送失败");
            }
            var rr = await WaitReplyAsync(cdp, site, ur, lr, _replyTimeoutSec);
            lastText = rr.text;
        }

        Info($"== 任务结束（共 {round} 轮）==");
        SetStatus("state", "任务结束");
        return CleanText(lastText);
    }

    private static string Truncate(string s, int n)
        => s == null ? "" : (s.Length <= n ? s.Replace('\n', ' ') : s.Substring(0, n).Replace('\n', ' ') + "...");

    /// <summary>去掉回复中残留的工具标记，得到可展示文本。</summary>
    public static string CleanText(string text)
    {
        if (text == null) return "";
        var t = ToolRegex.Replace(text, "");
        return t.Trim();
    }
}
