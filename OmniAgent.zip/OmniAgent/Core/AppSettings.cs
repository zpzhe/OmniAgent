using System.Text.Json;
using System.Text.Json.Serialization;

namespace OmniAgent.Core;

/// <summary>应用设置（保存到 BaseDir\config.json）。</summary>
public class AppSettings
{
    /// <summary>由命令行 --basedir 指定的配置根目录（安装版用）。</summary>
    public static string BaseDirOverride = "";

    public int Port { get; set; } = 9222;
    public string BaseDir { get; set; } = @"C:\_OmniAgent";
    public string BrowserExe { get; set; } = "";
    public int MaxRounds { get; set; } = 40;
    public int ReplyTimeoutSec { get; set; } = 300;
    public bool NewChat { get; set; } = true;
    public bool Embed { get; set; } = false;
    /// <summary>用户自定义的工作目录（AI 截图/脚本/文件默认存放处）；留空=BaseDir\work。</summary>
    public string WorkDirOverride { get; set; } = "";
    public List<SiteConfig> Sites { get; set; } = SiteConfig.Defaults();

    [JsonIgnore] public string ProfileDir => Path.Combine(BaseDir, "profile");
    [JsonIgnore] public string WorkDir =>
        !string.IsNullOrWhiteSpace(WorkDirOverride) ? WorkDirOverride : Path.Combine(BaseDir, "work");
    [JsonIgnore] public string ConfigPath => Path.Combine(BaseDir, "config.json");

    public static AppSettings Load()
    {
        var s = new AppSettings();
        if (!string.IsNullOrWhiteSpace(BaseDirOverride))
            s.BaseDir = BaseDirOverride.Trim();
        try
        {
            if (File.Exists(s.ConfigPath))
            {
                var loaded = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(s.ConfigPath),
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (loaded != null)
                {
                    var savedBase = loaded.BaseDir;
                    s = loaded;
                    // 命令行指定的根目录优先
                    if (!string.IsNullOrWhiteSpace(BaseDirOverride))
                        s.BaseDir = BaseDirOverride.Trim();
                    else if (string.IsNullOrWhiteSpace(savedBase))
                        s.BaseDir = new AppSettings().BaseDir;
                    s.Sites ??= SiteConfig.Defaults();
                    // 合并新版本新增的平台（旧 config.json 里没有的站点自动补上）
                    foreach (var d in SiteConfig.Defaults())
                    {
                        if (s.Sites.All(x => x.Id != d.Id))
                            s.Sites.Add(d);
                    }
                }
            }
        }
        catch { /* 配置损坏用默认 */ }
        return s;
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(BaseDir);
            File.WriteAllText(ConfigPath,
                JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    public SiteConfig FindSite(string id)
        => Sites.FirstOrDefault(x => x.Id == id) ?? SiteConfig.Defaults().First(x => x.Id == id);
}
