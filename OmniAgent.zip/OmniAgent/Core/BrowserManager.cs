using System.Diagnostics;
using System.Net;
using System.Text.Json.Nodes;

namespace OmniAgent.Core;

/// <summary>
/// 调试浏览器管理：查找 Chrome/Edge、以 CDP 调试端口启动、管理页面目标。
/// </summary>
public class BrowserManager
{
    public int Port { get; set; } = 9222;
    public string ProfileDir { get; set; }
    public string BrowserExe { get; set; }          // 空=自动查找
    public int MainPid { get; private set; }

    private static readonly HttpClient Http = new(new HttpClientHandler())
    {
        Timeout = TimeSpan.FromSeconds(10),
    };

    public static string FindBrowser()
    {
        string[] candidates =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Google\Chrome\Application\chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Google\Chrome\Application\chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Google\Chrome\Application\chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft\Edge\Application\msedge.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft\Edge\Application\msedge.exe"),
        };
        foreach (var c in candidates)
            if (File.Exists(c)) return c;
        return null;
    }

    /// <summary>调试端口是否已有浏览器在运行。</summary>
    public async Task<bool> IsRunningAsync()
    {
        try
        {
            var v = await Http.GetStringAsync($"http://127.0.0.1:{Port}/json/version");
            return v.Contains("webSocketDebuggerUrl");
        }
        catch { return false; }
    }

    /// <summary>启动（或复用）带调试端口的浏览器，返回 "REUSED" 或 "STARTED"。</summary>
    public async Task<string> LaunchAsync(string startUrl = "about:blank")
    {
        if (await IsRunningAsync()) return "REUSED";
        var exe = BrowserExe;
        if (string.IsNullOrEmpty(exe)) exe = FindBrowser();
        if (exe == null) throw new Exception("未找到 Chrome/Edge 浏览器，请安装其中之一。");

        var args = new List<string>
        {
            $"--remote-debugging-port={Port}",
            $"--user-data-dir=\"{ProfileDir}\"",
            "--remote-allow-origins=*",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-popup-blocking",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            "--disable-features=CalculateNativeWinOcclusion",
            "--disable-blink-features=AutomationControlled",
            "--test-type",
            "--restore-last-session=false",
            "--start-maximized",
            startUrl,
        };
        var psi = new ProcessStartInfo(exe)
        {
            UseShellExecute = true,
            Arguments = string.Join(" ", args),
        };
        try
        {
            var p = Process.Start(psi);
            MainPid = p?.Id ?? 0;
        }
        catch (Exception ex)
        {
            throw new Exception("启动浏览器失败: " + ex.Message);
        }

        for (int i = 0; i < 40; i++)
        {
            if (await IsRunningAsync()) return "STARTED";
            await Task.Delay(500);
        }
        throw new Exception("浏览器已启动但调试端口未就绪，请检查是否被安全软件拦截。");
    }

    /// <summary>列出全部页面目标。</summary>
    public async Task<JsonNode> GetTargetsAsync()
    {
        var s = await Http.GetStringAsync($"http://127.0.0.1:{Port}/json");
        return JsonNode.Parse(s);
    }

    /// <summary>新开一个标签页并返回其 target。</summary>
    public async Task<JsonNode> NewTabAsync(string url)
    {
        var resp = await Http.PutAsync($"http://127.0.0.1:{Port}/json/new?" + Uri.EscapeDataString(url), null);
        var s = await resp.Content.ReadAsStringAsync();
        return JsonNode.Parse(s);
    }

    /// <summary>找到已打开的站点标签页；没有则新开并等待加载完成。</summary>
    public async Task<JsonNode> FindOrOpenAsync(SiteConfig site)
    {
        var targets = await GetTargetsAsync();
        if (targets is JsonArray arr)
        {
            foreach (var t in arr)
            {
                var type = t["type"]?.GetValue<string>();
                var url = t["url"]?.GetValue<string>() ?? "";
                if (type == "page" && url.Contains(site.UrlHost, StringComparison.OrdinalIgnoreCase))
                    return t;
            }
        }
        var nt = await NewTabAsync(site.Url);
        var wsUrl = nt["webSocketDebuggerUrl"]?.GetValue<string>()
                    ?? throw new Exception("新标签页无调试地址");
        using (var c = await CdpClient.ConnectAsync(wsUrl))
        {
            await c.CallAsync("Page.enable");
            for (int i = 0; i < 60; i++)
            {
                var state = await c.EvalStringAsync("document.readyState", 8000);
                if (state == "complete" || state == "interactive") break;
                await Task.Delay(500);
            }
            await Task.Delay(1500); // 给 SPA 一点渲染时间
        }
        return nt;
    }

    /// <summary>关闭整个调试浏览器（发送 Browser.close）。</summary>
    public async Task CloseBrowserAsync()
    {
        try
        {
            var v = JsonNode.Parse(await Http.GetStringAsync($"http://127.0.0.1:{Port}/json/version"));
            var wsUrl = v["webSocketDebuggerUrl"]?.GetValue<string>();
            if (!string.IsNullOrEmpty(wsUrl))
            {
                using var c = await CdpClient.ConnectAsync(wsUrl);
                await c.CallAsync("Browser.close");
            }
        }
        catch { /* 未运行 */ }
    }

    /// <summary>找到浏览器主窗口句柄（按进程 ID；pid 为 0 时按类名匹配）。用于窗口嵌入。</summary>
    public IntPtr FindBrowserWindow(int pid)
    {
        var best = IntPtr.Zero;
        int bestArea = 0;
        Win32.EnumWindows((h, l) =>
        {
            if (!Win32.IsWindowVisible(h)) return true;
            var cls = Win32.GetWindowClass(h);
            if (pid != 0)
            {
                Win32.GetWindowThreadProcessId(h, out var wpid);
                if (wpid != pid) return true;
            }
            else if (!cls.Contains("Chrome_WidgetWin") && !cls.Contains("ChromeWindow"))
            {
                return true;
            }
            var title = Win32.GetWindowTitle(h);
            if (title.Length == 0) return true;
            Win32.GetWindowRect(h, out var r);
            var area = (r.Right - r.Left) * (r.Bottom - r.Top);
            if (area > bestArea) { bestArea = area; best = h; }
            return true;
        }, IntPtr.Zero);
        return best;
    }
}
