using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace OmniAgent.Core;

/// <summary>单个网页 AI 平台的适配配置。</summary>
public class SiteConfig
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Url { get; set; }
    public string UrlHost { get; set; }
    /// <summary>输入框选择器（按优先级尝试）。</summary>
    public string[] InputSel { get; set; }
    /// <summary>输入框类型：textarea（原生 textarea）或 contenteditable（富文本编辑器）。</summary>
    public string InputKind { get; set; }
    /// <summary>发送按钮选择器。</summary>
    public string[] SendSel { get; set; }
    /// <summary>停止生成按钮选择器（用于判断是否仍在生成，可为空）。</summary>
    public string[] StopSel { get; set; }
    /// <summary>AI 回复气泡选择器（取最后一个的文本）。</summary>
    public string[] AssistantSel { get; set; }
    /// <summary>用户消息气泡选择器（用于计数检测新回复）。</summary>
    public string[] UserSel { get; set; }
    /// <summary>新对话导航 URL（开始前打开以开新对话）。</summary>
    public string NewChatUrl { get; set; }
    /// <summary>新对话按钮选择器（可选）。</summary>
    public string[] NewChatSel { get; set; }

    [JsonIgnore]
    public bool IsContentEditable => string.Equals(InputKind, "contenteditable", StringComparison.OrdinalIgnoreCase);

    public override string ToString() => Name;

    // ---------- 六平台默认配置 ----------

    public static List<SiteConfig> Defaults() => new()
    {
        new SiteConfig
        {
            Id = "chatgpt", Name = "ChatGPT",
            Url = "https://chatgpt.com/", UrlHost = "chatgpt.com",
            InputSel = new[] { "#prompt-textarea", "textarea#mobile-composer-prompt", "[data-testid=\"prompt-textarea\"]", "textarea" },
            InputKind = "textarea",
            SendSel = new[] { "button[data-testid=\"send-button\"]", "button[aria-label=\"Send prompt\"]", "button[aria-label*=\"发送\"]" },
            StopSel = new[] { "button[data-testid=\"stop-button\"]" },
            AssistantSel = new[] { "[data-message-author-role=\"assistant\"]", ".markdown.prose", ".agent-turn" },
            UserSel = new[] { "[data-message-author-role=\"user\"]", "[data-testid=\"user-message\"]" },
            NewChatUrl = "https://chatgpt.com/",
        },
        new SiteConfig
        {
            Id = "doubao", Name = "豆包",
            Url = "https://www.doubao.com/chat/", UrlHost = "doubao.com",
            InputSel = new[] { ".tiptap.ProseMirror[contenteditable=\"true\"]", "[contenteditable=\"true\"]", "textarea" },
            InputKind = "contenteditable",
            SendSel = new[] { "button[data-testid=\"chat_input_send_button\"]", "button[aria-label*=\"发送\"]", "button[type=\"submit\"]" },
            StopSel = new[] { "button[data-testid=\"chat_input_stop_button\"]" },
            AssistantSel = new[] { "[data-testid=\"receive_message\"]", "[data-testid=\"receive_text_message\"]", "[class*=\"message-content\"]" },
            UserSel = new[] { "[data-testid=\"send_message\"]" },
            NewChatUrl = "https://www.doubao.com/chat/",
        },
        new SiteConfig
        {
            Id = "gemini", Name = "Gemini",
            Url = "https://gemini.google.com/app", UrlHost = "gemini.google.com",
            InputSel = new[] { ".ql-editor[contenteditable=\"true\"]", "rich-textarea [contenteditable=\"true\"]", "[contenteditable=\"true\"]" },
            InputKind = "contenteditable",
            SendSel = new[] { "button.send-button", "button[aria-label*=\"发送\"]", "button[aria-label*=\"Send\"]", "button[type=\"submit\"]" },
            StopSel = new[] { "button[aria-label*=\"Stop\"]", "button[aria-label*=\"停止\"]" },
            AssistantSel = new[] { ".model-response-text", "model-response .response-content", "message-content", "model-response" },
            UserSel = new[] { "user-query", ".query-text", ".user-query" },
            NewChatUrl = "https://gemini.google.com/app",
        },
        new SiteConfig
        {
            Id = "grok", Name = "Grok",
            Url = "https://grok.com/", UrlHost = "grok.com",
            InputSel = new[] { "textarea[data-testid=\"grok-input\"]", "textarea[placeholder*=\"Ask\"]", "textarea[placeholder*=\"Grok\"]", "textarea" },
            InputKind = "textarea",
            SendSel = new[] { "button[type=\"submit\"]", "button[data-testid=\"send-button\"]", "button[aria-label*=\"Send\"]", "button[aria-label*=\"发送\"]" },
            StopSel = new[] { "button[data-testid=\"stop-button\"]" },
            AssistantSel = new[] { "[data-testid=\"grok-response\"]", ".grok-response", "[class*=\"response\"]" },
            UserSel = new[] { "[data-testid=\"user-message\"]" },
            NewChatUrl = "https://grok.com/",
        },
        new SiteConfig
        {
            Id = "claude", Name = "Claude",
            Url = "https://claude.ai/", UrlHost = "claude.ai",
            InputSel = new[] { "div.ProseMirror[contenteditable=\"true\"]", "[data-testid=\"composer-input\"]", "div[role=\"textbox\"][contenteditable=\"true\"]", "[contenteditable=\"true\"]" },
            InputKind = "contenteditable",
            SendSel = new[] { "button[aria-label=\"Send message\"]", "button[aria-label=\"Send Message\"]", "button[data-testid=\"send-button\"]" },
            StopSel = new[] { "button[aria-label=\"Stop response\"]", "button[aria-label*=\"Stop\"]" },
            AssistantSel = new[] { ".font-claude-response", "[data-is-streaming]", "[data-testid=\"assistant-message\"]" },
            UserSel = new[] { ".font-user-message", "[data-testid=\"user-message\"]" },
            NewChatUrl = "https://claude.ai/new",
        },
        new SiteConfig
        {
            Id = "deepseek", Name = "DeepSeek",
            Url = "https://chat.deepseek.com/", UrlHost = "chat.deepseek.com",
            InputSel = new[] { "textarea#chat-input", "textarea", "[data-testid=\"chat-input\"]" },
            InputKind = "textarea",
            SendSel = new[] { "div[role=\"button\"].ds-button--primary.ds-button--circle", "button[aria-label=\"Send message\"]", "[data-testid=\"send-button\"]" },
            StopSel = new[] { "div[role=\"button\"].ds-button--circle:not(.ds-button--primary)" },
            AssistantSel = new[] { "[data-message-author-role=\"assistant\"]", "[class*=\"ds-assistant-message-main-content\"]", ".ds-markdown" },
            UserSel = new[] { "[data-message-author-role=\"user\"]", "[class*=\"fbb737a4\"]", "[class*=\"ds-user-message\"]" },
            NewChatUrl = "https://chat.deepseek.com/",
        },
        new SiteConfig
        {
            Id = "glm", Name = "GLM 智谱清言",
            Url = "https://chatglm.cn/", UrlHost = "chatglm.cn",
            InputSel = new[] { "textarea", "[contenteditable=\"true\"]" },
            InputKind = "textarea",
            SendSel = new[] { "button[aria-label*=\"发送\"]", "[class*=\"send-btn\"]", "[class*=\"send-button\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[class*=\"assistant\"]", "[class*=\"message-content\"]", "[class*=\"markdown\"]" },
            UserSel = new[] { "[class*=\"user\"]" },
            NewChatUrl = "https://chatglm.cn/",
        },
        new SiteConfig
        {
            Id = "zai", Name = "Z.ai (GLM)",
            Url = "https://chat.z.ai/", UrlHost = "chat.z.ai",
            InputSel = new[] { "textarea", "[contenteditable=\"true\"]" },
            InputKind = "textarea",
            SendSel = new[] { "button[type=\"submit\"]", "button[aria-label*=\"Send\"]", "[class*=\"send\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[class*=\"message\"]", "[class*=\"markdown\"]" },
            UserSel = new[] { "[class*=\"user\"]" },
            NewChatUrl = "https://chat.z.ai/",
        },
        new SiteConfig
        {
            Id = "kimi", Name = "Kimi",
            Url = "https://www.kimi.com/", UrlHost = "kimi.com",
            InputSel = new[] { "div[contenteditable=\"true\"]", "[class*=\"chat-input-editor\"]", "textarea" },
            InputKind = "contenteditable",
            SendSel = new[] { "[class*=\"send-button\"]", "button[aria-label*=\"发送\"]", "button[type=\"submit\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[class*=\"segment-content\"]", "[class*=\"markdown\"]", "[class*=\"message\"]" },
            UserSel = new[] { "[class*=\"user-content\"]", "[class*=\"user\"]" },
            NewChatUrl = "https://www.kimi.com/",
        },
        new SiteConfig
        {
            Id = "qwen", Name = "通义千问",
            Url = "https://www.qianwen.com/", UrlHost = "qianwen.com",
            InputSel = new[] { "[contenteditable=\"true\"]", "textarea" },
            InputKind = "contenteditable",
            SendSel = new[] { "button[aria-label*=\"发送\"]", "[class*=\"send-button\"]", "button[type=\"submit\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[class*=\"answer-content\"]", "[class*=\"markdown\"]", "[class*=\"message\"]" },
            UserSel = new[] { "[class*=\"question\"]", "[class*=\"user\"]" },
            NewChatUrl = "https://www.qianwen.com/",
        },
        new SiteConfig
        {
            Id = "yiyan", Name = "文心一言",
            Url = "https://wenxin.baidu.com/", UrlHost = "wenxin.baidu.com",
            InputSel = new[] { "textarea", "[contenteditable=\"true\"]" },
            InputKind = "textarea",
            SendSel = new[] { "[class*=\"send-btn\"]", "button[aria-label*=\"发送\"]", "[class*=\"send\"]", "button[type=\"submit\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[class*=\"answer\"]", "[class*=\"markdown\"]", "[class*=\"message\"]" },
            UserSel = new[] { "[class*=\"question\"]", "[class*=\"user\"]" },
            NewChatUrl = "https://wenxin.baidu.com/",
        },
        new SiteConfig
        {
            Id = "yuanbao", Name = "腾讯元宝",
            Url = "https://yuanbao.tencent.com/chat/", UrlHost = "yuanbao.tencent.com",
            InputSel = new[] { ".ql-editor[contenteditable=\"true\"]", "div[contenteditable=\"true\"]", "textarea" },
            InputKind = "contenteditable",
            SendSel = new[] { "[class*=\"SendButton_sendButton\"]", "div[aria-label=\"发送\"]", "button[aria-label*=\"发送\"]", "[class*=\"send-btn\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[class*=\"hyc-content\"]", "[class*=\"markdown\"]", "[class*=\"message\"]" },
            UserSel = new[] { "[class*=\"user\"]" },
            NewChatUrl = "https://yuanbao.tencent.com/chat/",
        },
        new SiteConfig
        {
            Id = "copilot", Name = "Copilot",
            Url = "https://copilot.microsoft.com/", UrlHost = "copilot.microsoft.com",
            InputSel = new[] { "textarea#userInput", "textarea[data-testid=\"composer-input\"]", "textarea" },
            InputKind = "textarea",
            SendSel = new[] { "button[aria-label*=\"Submit\"]", "button[aria-label*=\"Send\"]", "button[data-testid=\"send-button\"]" },
            StopSel = new[] { "button[aria-label*=\"Stop\"]" },
            AssistantSel = new[] { "[data-content=\"assistant\"]", "[data-testid=\"response-message\"]", "[class*=\"ac-textBlock\"]" },
            UserSel = new[] { "[data-content=\"user\"]", "[class*=\"user-turn\"]" },
            NewChatUrl = "https://copilot.microsoft.com/",
        },
        new SiteConfig
        {
            Id = "mistral", Name = "Mistral",
            Url = "https://chat.mistral.ai/", UrlHost = "chat.mistral.ai",
            InputSel = new[] { "div.ProseMirror[contenteditable=\"true\"]", "[contenteditable=\"true\"]" },
            InputKind = "contenteditable",
            SendSel = new[] { "button[aria-label=\"Send\"]", "button[aria-label*=\"Send\"]", "button[type=\"submit\"]" },
            StopSel = new[] { "[class*=\"stop\"]" },
            AssistantSel = new[] { "[data-message-author-role=\"assistant\"]", "[class*=\"assistant-message\"]" },
            UserSel = new[] { "[data-message-author-role=\"user\"]", "[class*=\"user-message\"]" },
            NewChatUrl = "https://chat.mistral.ai/chat",
        },
    };

    public static List<SiteConfig> Load(string configPath)
    {
        var list = Defaults();
        try
        {
            if (File.Exists(configPath))
            {
                var j = JsonNode.Parse(File.ReadAllText(configPath));
                if (j is JsonObject o && o["sites"] is JsonArray arr)
                {
                    foreach (var s in arr.AsArray())
                    {
                        var id = s["Id"]?.GetValue<string>();
                        var exist = list.FirstOrDefault(x => x.Id == id);
                        if (exist != null)
                        {
                            var idx = list.IndexOf(exist);
                            var parsed = s.Deserialize<SiteConfig>(new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                            list[idx] = parsed;
                        }
                    }
                }
            }
        }
        catch { /* 配置损坏时用默认值 */ }
        return list;
    }

    public static void Save(string configPath, List<SiteConfig> sites)
    {
        var obj = new JsonObject { ["sites"] = JsonSerializer.SerializeToNode(sites) };
        Directory.CreateDirectory(Path.GetDirectoryName(configPath));
        File.WriteAllText(configPath, obj.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
    }
}
