param($png, [int]$y1 = 0, [int]$y2 = 0, [int]$stepY = 4)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::new($png)
$W = $bmp.Width; $H = $bmp.Height
if ($y2 -eq 0) { $y2 = $H }
$out = "ink ${W}x${H} y[$y1..$y2] step=$stepY`n"
for ($y = $y1; $y -lt $y2; $y += $stepY) {
  $runs = @()
  $inRun = $false; $start = 0
  for ($x = 0; $x -lt $W; $x += 2) {
    $p = $bmp.GetPixel($x, $y); $rr = [int]$p.R; $gg = [int]$p.G; $bb = [int]$p.B
    # 非背景 = 不是深底(15,17,21)/栏(22,24,29) 的像素（文字/边框/按钮色/渐变）
    $isBg = ([math]::Abs($rr - 15) + [math]::Abs($gg - 17) + [math]::Abs($bb - 21) -lt 26) -or ([math]::Abs($rr - 22) + [math]::Abs($gg - 24) + [math]::Abs($bb - 29) -lt 26)
    if (-not $isBg) {
      if (-not $inRun) { $inRun = $true; $start = $x }
    } else {
      if ($inRun) { $runs += "$start-$($x-2)"; $inRun = $false }
    }
  }
  if ($inRun) { $runs += "$start-$($W-1)" }
  $out += ("y={0,4}  {1}" -f $y, ($runs -join ", ")) + "`n"
}
$bmp.Dispose()
Write-Output $out
