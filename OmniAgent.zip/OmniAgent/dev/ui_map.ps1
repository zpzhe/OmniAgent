param($png, [int]$cols = 16, [int]$rows = 14)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::new($png)
$W = $bmp.Width; $H = $bmp.Height
$cw = [int][math]::Floor($W / $cols); $ch = [int][math]::Floor($H / $rows)
$out = "map ${W}x${H} cell ${cw}x${ch}`n"
for ($r = 0; $r -lt $rows; $r++) {
  $line = ""
  for ($c = 0; $c -lt $cols; $c++) {
    $nB = 0; $nA = 0; $nP = 0; $nU = 0; $nV = 0; $nG = 0; $nW = 0; $nO = 0
    $stepX = [math]::Max(2, [int]($cw / 5)); $stepY = [math]::Max(2, [int]($ch / 5))
    for ($y = $r * $ch; $y -lt ($r + 1) * $ch - 1; $y += $stepY) {
      for ($x = $c * $cw; $x -lt ($c + 1) * $cw - 1; $x += $stepX) {
        $p = $bmp.GetPixel($x, $y); $rr = [int]$p.R; $gg = [int]$p.G; $bb = [int]$p.B
        if ([math]::Abs($rr - 15) + [math]::Abs($gg - 17) + [math]::Abs($bb - 21) -lt 30 -or ($rr -lt 45 -and $gg -lt 45 -and $bb -lt 50)) { $nB++ }
        elseif ([math]::Abs($rr - 22) + [math]::Abs($gg - 24) + [math]::Abs($bb - 29) -lt 30 -or ($rr -ge 45 -and $rr -lt 75 -and $gg -ge 45 -and $gg -lt 75 -and $bb -ge 45 -and $bb -lt 80)) { $nA++ }
        elseif ([math]::Abs($rr - 28) + [math]::Abs($gg - 30) + [math]::Abs($bb - 38) -lt 30 -or ($rr -ge 75 -and $rr -lt 120 -and $gg -ge 75 -and $gg -lt 120 -and $bb -ge 75 -and $bb -lt 130)) { $nP++ }
        elseif ($bb -gt 170 -and $rr -lt 140 -and $gg -lt 160 -and ($bb - $rr) -gt 60) { $nU++ }
        elseif ($bb -gt 170 -and $rr -ge 100 -and $gg -lt 150 -and $rr -lt 200) { $nV++ }
        elseif ($gg -gt 140 -and $rr -lt 120 -and $bb -lt 160 -and ($gg - $rr) -gt 40) { $nG++ }
        elseif ($rr -gt 228 -and $gg -gt 228 -and $bb -gt 228) { $nW++ }
        else { $nO++ }
      }
    }
    $best = 'O'; $bestN = $nO
    if ($nB -gt $bestN) { $best = 'B'; $bestN = $nB }
    if ($nA -gt $bestN) { $best = 'A'; $bestN = $nA }
    if ($nP -gt $bestN) { $best = 'P'; $bestN = $nP }
    if ($nU -gt $bestN) { $best = 'U'; $bestN = $nU }
    if ($nV -gt $bestN) { $best = 'V'; $bestN = $nV }
    if ($nG -gt $bestN) { $best = 'G'; $bestN = $nG }
    if ($nW -gt $bestN) { $best = 'W'; $bestN = $nW }
    $line += $best
  }
  $out += $line + "`n"
}
$bmp.Dispose()
Write-Output $out
