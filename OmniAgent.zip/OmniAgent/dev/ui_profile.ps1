param($png, [int]$stepY = 8)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::new($png)
$W = $bmp.Width; $H = $bmp.Height
Write-Output "profile ${W}x${H} stepY=$stepY"
for ($y = 0; $y -lt $H; $y += $stepY) {
  $nB = 0; $nA = 0; $nP = 0; $nU = 0; $nV = 0; $nG = 0; $nW = 0; $nO = 0
  for ($x = 0; $x -lt $W; $x += 6) {
    $p = $bmp.GetPixel($x, $y); $rr = [int]$p.R; $gg = [int]$p.G; $bb = [int]$p.B
    if ([math]::Abs($rr - 15) + [math]::Abs($gg - 17) + [math]::Abs($bb - 21) -lt 30 -or ($rr -lt 45 -and $gg -lt 45 -and $bb -lt 50)) { $nB++ }
    elseif ([math]::Abs($rr - 22) + [math]::Abs($gg - 24) + [math]::Abs($bb - 29) -lt 30 -or ($rr -ge 45 -and $rr -lt 75 -and $gg -ge 45 -and $gg -lt 75 -and $bb -ge 45 -and $bb -lt 80)) { $nA++ }
    elseif ([math]::Abs($rr - 28) + [math]::Abs($gg - 30) + [math]::Abs($bb - 38) -lt 30 -or ($rr -ge 75 -and $rr -lt 120 -and $gg -ge 75 -and $gg -lt 120 -and $bb -ge 75 -and $bb -lt 130)) { $nP++ }
    elseif ($bb -gt 170 -and $rr -lt 140 -and $gg -lt 160 -and ($bb - $rr) -gt 60) { $nU++ }
    elseif ($bb -gt 170 -and $rr -ge 100 -and $gg -lt 150 -and $rr -lt 200) { $nV++ }
    elseif ($gg -gt 140 -and $rr -lt 120 -and $bb -lt 160 -and ($gg - $rr) -gt 40) { $nG++ }
    elseif ($rr -gt 228 -and $gg -gt 228 -and $bb -gt 228) { $nW++ }
    else { $nO++ }
  }
  $total = $nB + $nA + $nP + $nU + $nV + $nG + $nW + $nO
  $bar = ""
  foreach ($pair in @(@('B', $nB), @('A', $nA), @('P', $nP), @('U', $nU), @('V', $nV), @('G', $nG), @('W', $nW), @('O', $nO))) {
    $pct = [int](100 * $pair[1] / $total)
    if ($pct -ge 8) { $bar += "$($pair[0])$pct% " }
  }
  Write-Output ("y={0,4}  {1}" -f $y, $bar)
}
$bmp.Dispose()
