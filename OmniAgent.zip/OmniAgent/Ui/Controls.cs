using System.Drawing.Drawing2D;

namespace OmniAgent.Ui;

/// <summary>深色主题色板。</summary>
public static class Theme
{
    public static readonly Color Bg = Color.FromArgb(15, 17, 21);          // 窗体底色
    public static readonly Color Bar = Color.FromArgb(22, 24, 29);         // 顶栏/底栏
    public static readonly Color Panel = Color.FromArgb(28, 30, 38);       // 面板
    public static readonly Color PanelLight = Color.FromArgb(40, 43, 54);  // 悬浮面板
    public static readonly Color Border = Color.FromArgb(46, 49, 60);      // 边框
    public static readonly Color Text = Color.FromArgb(232, 234, 240);     // 主文字
    public static readonly Color Dim = Color.FromArgb(150, 156, 170);      // 次级文字
    public static readonly Color Accent = Color.FromArgb(78, 124, 246);    // 主色蓝
    public static readonly Color Accent2 = Color.FromArgb(139, 92, 246);   // 渐变紫
    public static readonly Color Success = Color.FromArgb(52, 199, 123);   // 成功绿
    public static readonly Color Danger = Color.FromArgb(240, 82, 82);     // 危险红
    public static readonly Color Warn = Color.FromArgb(245, 166, 35);      // 警告橙
    public static readonly Color CodeBg = Color.FromArgb(13, 15, 20);      // 代码块底色
    public static readonly Color Pink = Color.FromArgb(236, 72, 153);      // 点缀粉

    public static readonly Font UiFont = new("Microsoft YaHei UI", 9.5f);
    public static readonly Font UiFontBold = new("Microsoft YaHei UI", 9.5f, FontStyle.Bold);
    public static readonly Font TitleFont = new("Microsoft YaHei UI", 13f, FontStyle.Bold);
    public static readonly Font BigFont = new("Microsoft YaHei UI", 17f, FontStyle.Bold);
    public static readonly Font MonoFont = new("Consolas", 9f);
    public static readonly Font SmallFont = new("Microsoft YaHei UI", 8.5f);

    public static GraphicsPath Rounded(RectangleF r, float rad)
    {
        var p = new GraphicsPath();
        if (rad <= 0) { p.AddRectangle(r); return p; }
        float d = rad * 2;
        if (d > r.Width) d = r.Width;
        if (d > r.Height) d = r.Height;
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    /// <summary>向上查找第一个非透明背景色（用于自绘控件擦除旧像素）。</summary>
    public static Color FindBackColor(Control c)
    {
        var p = c?.Parent;
        while (p != null)
        {
            if (p.BackColor != Color.Transparent) return p.BackColor;
            p = p.Parent;
        }
        return Bar;
    }
}

/// <summary>深色主题下拉框（自绘下拉列表，适配暗色界面）。</summary>
public class DarkComboBox : ComboBox
{
    public DarkComboBox()
    {
        FlatStyle = FlatStyle.Flat;
        DrawMode = DrawMode.OwnerDrawFixed;
        DropDownStyle = ComboBoxStyle.DropDownList;
        BackColor = Theme.Panel;
        ForeColor = Theme.Text;
        Font = Theme.UiFont;
        IntegralHeight = false;
        MaxDropDownItems = 12;
    }

    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        if (e.Index < 0) { base.OnDrawItem(e); return; }
        e.DrawBackground();
        var g = e.Graphics;
        var selected = (e.State & DrawItemState.Selected) != 0;
        using (var b = new SolidBrush(selected ? Theme.PanelLight : Theme.Panel))
            g.FillRectangle(b, e.Bounds);
        if (selected)
        {
            using var bar = new SolidBrush(Theme.Accent2);
            g.FillRectangle(bar, e.Bounds.X, e.Bounds.Y + 3, 3, e.Bounds.Height - 6);
        }
        TextRenderer.DrawText(g, GetItemText(Items[e.Index]), Font,
            new Rectangle(e.Bounds.X + 10, e.Bounds.Y, e.Bounds.Width - 14, e.Bounds.Height),
            selected ? Theme.Text : Theme.Dim,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis);
    }
}

/// <summary>圆角面板（支持渐变填充与描边）。</summary>
public class RoundedPanel : Panel
{
    public int Radius { get; set; } = 12;
    public Color Fill { get; set; } = Theme.Panel;
    public Color Fill2 { get; set; } = Color.Empty;
    public Color BorderCol { get; set; } = Theme.Border;
    public float BorderWidth { get; set; } = 1f;
    public float GradientAngle { get; set; } = 90f;

    public RoundedPanel()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Color.Transparent;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
        using var path = Theme.Rounded(rect, Radius);
        if (Fill2 != Color.Empty && Fill2 != Fill)
        {
            using var brush = new LinearGradientBrush(rect, Fill, Fill2, GradientAngle);
            g.FillPath(brush, path);
        }
        else
        {
            using var brush = new SolidBrush(Fill);
            g.FillPath(brush, path);
        }
        if (BorderWidth > 0 && BorderCol != Color.Empty)
        {
            using var pen = new Pen(BorderCol, BorderWidth);
            g.DrawPath(pen, path);
        }
        base.OnPaint(e);
    }
}

/// <summary>渐变主按钮。</summary>
public class AccentButton : Button
{
    public Color Base1 { get; set; } = Theme.Accent;
    public Color Base2 { get; set; } = Theme.Accent2;
    public int Radius { get; set; } = 10;
    private bool _hover, _down;

    public AccentButton()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer, true);
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Cursor = Cursors.Hand;
        Font = Theme.UiFontBold;
        ForeColor = Color.White;
    }

    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _down = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { _down = true; Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { _down = false; Invalidate(); base.OnMouseUp(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        // 先擦除自身背景（UserPaint 控件不会自动擦除，避免移动/重排后残留旧像素）
        using (var bg = new SolidBrush(Theme.FindBackColor(this)))
            g.FillRectangle(bg, 0, 0, Width, Height);
        var rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
        using var path = Theme.Rounded(rect, Radius);
        if (!Enabled)
        {
            using var b = new SolidBrush(Color.FromArgb(90, 60, 66, 82));
            g.FillPath(b, path);
        }
        else
        {
            var c1 = _down ? Darken(Base1, 0.82f) : _hover ? Lighten(Base1, 1.12f) : Base1;
            var c2 = _down ? Darken(Base2, 0.82f) : _hover ? Lighten(Base2, 1.12f) : Base2;
            using var brush = new LinearGradientBrush(rect, c1, c2, 90f);
            g.FillPath(brush, path);
        }
        var color = Enabled ? Color.White : Color.FromArgb(150, 154, 168);
        TextRenderer.DrawText(g, Text, Font, new Rectangle(0, 0, Width, Height), color,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
    }

    internal static Color Lighten(Color c, float f) =>
        Color.FromArgb(c.A, (int)Math.Min(255, c.R * f), (int)Math.Min(255, c.G * f), (int)Math.Min(255, c.B * f));
    internal static Color Darken(Color c, float f) =>
        Color.FromArgb(c.A, (int)(c.R * f), (int)(c.G * f), (int)(c.B * f));
}

/// <summary>幽灵按钮（深色描边、悬浮高亮）。</summary>
public class GhostButton : Button
{
    public int Radius { get; set; } = 8;
    public Color HoverFill { get; set; } = Theme.PanelLight;
    public Color NormalFill { get; set; } = Theme.Panel;
    private bool _hover, _down;

    public GhostButton()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer, true);
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Cursor = Cursors.Hand;
        Font = Theme.UiFont;
        ForeColor = Theme.Text;
    }

    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _down = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { _down = true; Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { _down = false; Invalidate(); base.OnMouseUp(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
        using var path = Theme.Rounded(rect, Radius);
        using (var b = new SolidBrush(_down ? Darken(HoverFill, 0.9f) : _hover ? HoverFill : NormalFill))
            g.FillPath(b, path);
        using (var pen = new Pen(Theme.Border, 1f))
            g.DrawPath(pen, path);
        var color = Enabled ? ForeColor : Theme.Dim;
        TextRenderer.DrawText(g, Text, Font, new Rectangle(0, 0, Width, Height), color,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
    }

    internal static Color Darken(Color c, float f) =>
        Color.FromArgb(c.A, (int)(c.R * f), (int)(c.G * f), (int)(c.B * f));
}

/// <summary>分段切换按钮（对话/浏览器/日志）。</summary>
public class SegButton : Button
{
    public bool Selected { get; set; }
    public Color SelectedBg { get; set; } = Theme.PanelLight;
    public Color Bar { get; set; } = Theme.Accent2;
    private bool _hover;

    public SegButton()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer, true);
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Cursor = Cursors.Hand;
        Font = Theme.UiFont;
        ForeColor = Theme.Dim;
        Height = 30;
    }

    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        // 先擦除自身背景（UserPaint 控件不会自动擦除，避免移动/重排后残留旧像素）
        using (var bg = new SolidBrush(Theme.FindBackColor(this)))
            g.FillRectangle(bg, 0, 0, Width, Height);
        var rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
        if (Selected && Enabled)
        {
            using (var b = new SolidBrush(SelectedBg))
            {
                using var path = Theme.Rounded(rect, 8);
                g.FillPath(b, path);
            }
        }
        else if (_hover && Enabled)
        {
            using (var b = new SolidBrush(SelectedBg))
            {
                using var path = Theme.Rounded(rect, 8);
                g.FillPath(b, path);
            }
        }
        if (Selected && Enabled)
        {
            using var pen = new Pen(Bar, 2.5f);
            g.DrawLine(pen, Width * 0.22f, Height - 2f, Width * 0.78f, Height - 2f);
        }
        var color = Enabled ? (Selected || _hover ? Theme.Text : Theme.Dim) : Color.FromArgb(90, 96, 108);
        TextRenderer.DrawText(g, Text, Font, new Rectangle(0, 0, Width, Height), color,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
    }
}

/// <summary>一条 AI 消息（气泡 + 头行 + 正文），支持流式更新文本。</summary>
public class AiMessage
{
    public RoundedPanel Panel;
    public Label Head;
    public Label Body;
    public string Text = "";
    public bool Done;
}

/// <summary>聊天视图：气泡流 + 欢迎页 + 打字动画 + 自动滚动。</summary>
public class ChatPanel : Panel
{
    public FlowLayoutPanel Flow;
    public event Action<string> SuggestionClicked;

    /// <summary>欢迎页功能标语（在标题下方显示）。</summary>
    public string WelcomeCaption
    {
        get => _captionLbl?.Text ?? "";
        set { if (_captionLbl != null) _captionLbl.Text = value; }
    }

    private Label _captionLbl;
    private readonly List<Control> _userBubbles = new();
    private Control _typing;
    private Panel _welcome;
    private readonly Font _bodyFont = new("Microsoft YaHei UI", 10f);
    private const int SidePad = 18;

    public ChatPanel()
    {
        BackColor = Theme.Bg;
        AutoScroll = true;
        DoubleBuffered = true;
        Flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Theme.Bg,
            Padding = new Padding(SidePad, 14, SidePad, 10),
        };
        Controls.Add(Flow);
        BuildWelcome();
        Resize += (s, e) => UpdateUserMargins();
    }

    private void BuildWelcome()
    {
        _welcome = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Bg, Visible = true };
        var center = new TableLayoutPanel
        {
            AutoSize = true,
            ColumnCount = 1,
            RowCount = 4,
            BackColor = Color.Transparent,
        };
        center.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        center.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        center.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        center.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        center.Controls.Add(new Label
        {
            Text = "让 AI 替你操作这台电脑",
            Font = Theme.BigFont,
            ForeColor = Theme.Text,
            AutoSize = true,
            Margin = new Padding(0, 0, 0, 6),
        }, 0, 0);
        center.Controls.Add(_captionLbl = new Label
        {
            Text = "",
            Font = Theme.UiFontBold,
            ForeColor = Theme.Accent2,
            AutoSize = true,
            Margin = new Padding(0, 0, 0, 6),
        }, 0, 1);
        center.Controls.Add(new Label
        {
            Text = "选择一个 AI 平台，输入任务——它会自己截图看屏幕、动鼠标键盘、执行命令，直到任务完成",
            Font = Theme.UiFont,
            ForeColor = Theme.Dim,
            AutoSize = true,
            Margin = new Padding(0, 0, 0, 18),
        }, 0, 2);
        var chips = new FlowLayoutPanel { AutoSize = true, WrapContents = true, MaximumSize = new Size(680, 0), BackColor = Color.Transparent };
        foreach (var s in new[] { "整理桌面", "写个 Python 脚本计算圆周率", "截图并总结当前屏幕", "把 D 盘日志合并成一个文件" })
        {
            // 不用 AutoSize（Button.AutoSize 会以中心为基准漂移），改为测量宽度
            var chip = new GhostButton
            {
                Text = s,
                AutoSize = false,
                Height = 30,
                Width = TextRenderer.MeasureText(s, Theme.UiFont).Width + 26,
                Margin = new Padding(0, 0, 10, 10),
                ForeColor = Theme.Text,
                NormalFill = Theme.Panel,
            };
            chip.Click += (s2, e2) => SuggestionClicked?.Invoke(s);
            chips.Controls.Add(chip);
        }
        center.Controls.Add(chips, 0, 3);
        _welcome.Controls.Add(center);
        _welcome.Resize += (s, e) =>
        {
            center.Left = Math.Max(0, (_welcome.ClientSize.Width - center.Width) / 2);
            center.Top = Math.Max(20, (_welcome.ClientSize.Height - center.Height) / 2 - 30);
        };
        Controls.Add(_welcome);
        _welcome.BringToFront();
        Flow.Resize += (s, e) => UpdateUserMargins();
    }

    private int BubbleMaxWidth => Math.Max(260, Math.Min(620, ClientSize.Width - SidePad * 2 - 80));

    // ---------- 气泡 ----------

    private RoundedPanel MakeBubble(string text, Color fg, Color c1, Color c2, int radius, out Label lbl)
    {
        var bubble = new RoundedPanel
        {
            Fill = c1,
            Fill2 = c2,
            BorderCol = Color.Empty,
            BorderWidth = 0,
            Radius = radius,
        };
        // 右侧预留 34px 给头像圆点
        var maxW = Math.Max(200, BubbleMaxWidth - 40) - 34;
        var size = TextRenderer.MeasureText(text, _bodyFont, new Size(maxW, 2000),
            TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
        lbl = new Label
        {
            Text = text,
            AutoSize = false,
            Font = _bodyFont,
            ForeColor = fg,
            Size = new Size(Math.Max(60, size.Width), Math.Max(16, size.Height)),
            Location = new Point(14, 10),
        };
        bubble.Controls.Add(lbl);
        bubble.Width = lbl.Width + 28 + 34;
        bubble.Height = lbl.Height + 20;
        return bubble;
    }

    private RoundedPanel MakeAvatar(string text, Color border = default)
    {
        var av = new RoundedPanel
        {
            Fill = Theme.Accent,
            Fill2 = Theme.Accent2,
            BorderCol = border == default ? Color.Empty : border,
            BorderWidth = border == default ? 0 : 1.5f,
            Radius = 11,
            Width = 22,
            Height = 22,
        };
        av.Controls.Add(new Label
        {
            Text = text,
            AutoSize = false,
            Size = new Size(22, 22),
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Microsoft YaHei UI", 7f, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            Location = new Point(0, 0),
        });
        return av;
    }

    public void AddUser(string text)
    {
        _welcome.Visible = false;
        var bubble = MakeBubble(text, Color.White, Theme.Accent, Theme.Accent2, 14, out var lbl);
        var avatar = MakeAvatar("我", Color.FromArgb(200, 255, 255, 255));
        avatar.Location = new Point(bubble.Width - 30, 6);
        bubble.Controls.Add(avatar);
        bubble.Margin = new Padding(SidePad, 6, SidePad, 6);
        Flow.Controls.Add(bubble);
        _userBubbles.Add(bubble);
        UpdateUserMargins();
        ScrollToBottom();
    }

    public AiMessage AddAi(string text, bool done = false)
    {
        _welcome.Visible = false;
        var msg = new AiMessage { Done = done };
        var bubble = new RoundedPanel
        {
            Fill = Theme.Panel,
            BorderCol = Theme.Border,
            BorderWidth = 1,
            Radius = 14,
        };
        msg.Head = new Label
        {
            Text = "",
            AutoSize = true,
            Font = Theme.SmallFont,
            ForeColor = Theme.Success,
            Location = new Point(46, 8),
            Visible = false,
        };
        msg.Body = new Label
        {
            AutoSize = false,
            Font = _bodyFont,
            ForeColor = Theme.Text,
        };
        bubble.Controls.Add(msg.Head);
        bubble.Controls.Add(msg.Body);
        var avatar = MakeAvatar("AI");
        avatar.Location = new Point(12, 8);
        bubble.Controls.Add(avatar);
        msg.Panel = bubble;
        msg.Text = text;
        LayoutAi(msg);
        bubble.Margin = new Padding(SidePad, 6, SidePad, 6);
        Flow.Controls.Add(bubble);
        ScrollToBottom();
        return msg;
    }

    /// <summary>更新 AI 消息文本（流式刷新）。</summary>
    public void SetAiText(AiMessage msg, string text, bool done = false)
    {
        msg.Text = text;
        if (done && !msg.Done)
        {
            msg.Done = true;
            msg.Head.Text = "✓ 任务完成";
            msg.Head.ForeColor = Theme.Success;
            msg.Head.Visible = true;
        }
        LayoutAi(msg);
        ScrollToBottom();
    }

    private void LayoutAi(AiMessage msg)
    {
        msg.Head.Visible = msg.Done && msg.Head.Text.Length > 0;
        var maxW = Math.Max(240, BubbleMaxWidth - 40);
        var size = TextRenderer.MeasureText(msg.Text, _bodyFont, new Size(maxW, 2000),
            TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
        msg.Body.Size = new Size(Math.Max(80, size.Width), Math.Max(16, size.Height));
        msg.Body.Location = new Point(46, msg.Head.Visible ? msg.Head.Bottom + 2 : 10);
        msg.Panel.Width = msg.Body.Width + 60;
        msg.Panel.Height = msg.Body.Bottom + 10;
    }

    public void AddTool(string name, string args, string output)
    {
        _welcome.Visible = false;
        var card = new RoundedPanel
        {
            Fill = Theme.Bar,
            BorderCol = Theme.Border,
            Radius = 12,
            Width = Math.Max(320, ClientSize.Width - SidePad * 2 - 24),
            Margin = new Padding(SidePad, 8, SidePad, 2),
        };
        var head = new Label
        {
            Text = $"⚙ 工具调用 · {name}",
            AutoSize = true,
            Font = Theme.UiFontBold,
            ForeColor = Theme.Accent2,
            Location = new Point(14, 10),
        };
        card.Controls.Add(head);
        var argsLbl = new Label
        {
            Text = Truncate(args, 140),
            AutoSize = true,
            Font = Theme.SmallFont,
            ForeColor = Theme.Dim,
            Location = new Point(16, 32),
            MaximumSize = new Size(card.Width - 32, 0),
        };
        card.Controls.Add(argsLbl);
        var shown = Truncate(output, 4000);
        var box = new TextBox
        {
            Multiline = true,
            ReadOnly = true,
            BorderStyle = BorderStyle.None,
            BackColor = Theme.CodeBg,
            ForeColor = Color.FromArgb(170, 205, 175),
            Font = Theme.MonoFont,
            ScrollBars = ScrollBars.None,
            WordWrap = true,
            Text = shown,
            Location = new Point(14, argsLbl.Bottom + 6),
            Width = card.Width - 28,
            Height = Math.Min(170, Math.Max(40, shown.Split('\n').Length * 17 + 8)),
        };
        card.Controls.Add(box);
        card.Height = box.Bottom + 10;
        Flow.Controls.Add(card);
        ScrollToBottom();
    }

    public void AddSystem(string text, Color? color = null)
    {
        _welcome.Visible = false;
        var lbl = new Label
        {
            Text = text,
            AutoSize = true,
            Font = Theme.SmallFont,
            ForeColor = color ?? Theme.Dim,
            MaximumSize = new Size(Math.Max(200, ClientSize.Width - SidePad * 2 - 24), 0),
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(SidePad, 10, SidePad, 0),
            Padding = new Padding(6, 2, 6, 2),
        };
        Flow.Controls.Add(lbl);
        ScrollToBottom();
    }

    // ---------- 打字动画 ----------

    public Control AddTyping()
    {
        RemoveTyping();
        _welcome.Visible = false;
        var bubble = new RoundedPanel
        {
            Fill = Theme.Panel,
            BorderCol = Theme.Border,
            Radius = 14,
            Width = 130,
            Height = 40,
            Margin = new Padding(SidePad, 6, SidePad, 6),
        };
        var lbl = new Label
        {
            Text = "● ○ ○",
            AutoSize = true,
            Font = new Font("Microsoft YaHei UI", 11f),
            ForeColor = Theme.Accent2,
            Location = new Point(46, 10),
        };
        bubble.Controls.Add(lbl);
        var avatar = MakeAvatar("AI");
        avatar.Location = new Point(12, 9);
        bubble.Controls.Add(avatar);
        Flow.Controls.Add(bubble);
        _typing = bubble;
        var timer = new System.Windows.Forms.Timer { Interval = 400 };
        int frame = 0;
        timer.Tick += (s, e) =>
        {
            frame = (frame + 1) % 3;
            lbl.Text = frame switch
            {
                0 => "● ○ ○",
                1 => "○ ● ○",
                _ => "○ ○ ●",
            };
        };
        timer.Start();
        bubble.Tag = timer;
        ScrollToBottom();
        return bubble;
    }

    public void RemoveTyping()
    {
        if (_typing == null) return;
        var t = _typing.Tag as System.Windows.Forms.Timer;
        t?.Stop();
        t?.Dispose();
        Flow.Controls.Remove(_typing);
        _typing.Dispose();
        _typing = null;
    }

    // ---------- 其他 ----------

    public void Clear()
    {
        RemoveTyping();
        Flow.Controls.Clear();
        _userBubbles.Clear();
        _welcome.Visible = true;
        _welcome.BringToFront();
    }

    private void UpdateUserMargins()
    {
        var flowW = Flow.ClientSize.Width - SidePad * 2;
        foreach (var b in _userBubbles)
        {
            b.Margin = new Padding(Math.Max(SidePad, flowW - b.Width), 6, SidePad, 6);
        }
    }

    private void ScrollToBottom()
    {
        if (!IsHandleCreated) return;
        try
        {
            BeginInvoke(new Action(() =>
            {
                AutoScrollPosition = new Point(0, Flow.Height + 40);
            }));
        }
        catch { }
    }

    private static string Truncate(string s, int n)
    {
        if (string.IsNullOrEmpty(s)) return "";
        return s.Length <= n ? s : s.Substring(0, n) + " …";
    }
}
