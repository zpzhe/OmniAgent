using System.Runtime.InteropServices;

namespace OmniAgentSetup;

static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        // net48 没有 Application.SetHighDpiMode，直接用同等效果的 Win32 声明式 DPI 感知
        try { SetProcessDPIAware(); } catch { }
        if (args.Length >= 2 && args[0] == "--silent")
        {
            var f = new SetupForm();
            f.InstallSilent(args[1]);
            return;
        }
        Application.Run(new SetupForm());
    }

    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();
}

/// <summary>OmniAgent 安装向导：选择目录 → 释放主程序 → 创建快捷方式与卸载入口。</summary>
public class SetupForm : Form
{
    // 深色主题（独立实现，不依赖主程序）
    private static readonly Color Bg = Color.FromArgb(15, 17, 21);
    private static readonly Color Bar = Color.FromArgb(22, 24, 29);
    private static readonly Color Panel = Color.FromArgb(28, 30, 38);
    private static readonly Color TextC = Color.FromArgb(232, 234, 240);
    private static readonly Color Dim = Color.FromArgb(150, 156, 170);
    private static readonly Color Accent = Color.FromArgb(78, 124, 246);
    private static readonly Color Accent2 = Color.FromArgb(139, 92, 246);
    private static readonly Color Success = Color.FromArgb(52, 199, 123);
    private static readonly Color Danger = Color.FromArgb(240, 82, 82);
    private static readonly Color Warn = Color.FromArgb(245, 166, 35);

    private TextBox txtDir;
    private CheckBox chkDesktop, chkStartMenu;
    private Button btnInstall, btnRun, btnClose, btnBrowse;
    private Label lblStatus;
    private ProgressBar pb;
    private string _installedExe = "";

    public SetupForm()
    {
        Text = "OmniAgent 安装向导";
        ClientSize = new Size(680, 470);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Bg;
        ForeColor = TextC;
        Font = new Font("Microsoft YaHei UI", 9.5f);
        Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        AutoScaleMode = AutoScaleMode.None;
        HandleCreated += (s, e) => ApplyDarkTitleBar();
        BuildUi();
    }

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

    private void ApplyDarkTitleBar()
    {
        try
        {
            int v = 1;
            DwmSetWindowAttribute(Handle, 20, ref v, 4); // 沉浸式深色模式
            if (Environment.OSVersion.Version.Build >= 22000)
            {
                int c = Bar.ToArgb();
                DwmSetWindowAttribute(Handle, 35, ref c, 4); // Win11 标题栏色
            }
        }
        catch { }
    }

    private static Button MakeButton(string text, Color bg, Color fg, int w, int h)
        => new()
        {
            Text = text,
            Width = w,
            Height = h,
            FlatStyle = FlatStyle.Flat,
            FlatAppearance = { BorderSize = 0 },
            BackColor = bg,
            ForeColor = fg,
            Font = new Font("Microsoft YaHei UI", 9.5f),
            Cursor = Cursors.Hand,
        };

    private void BuildUi()
    {
        Controls.Add(new Label
        {
            Text = "OmniAgent 安装向导",
            AutoSize = true,
            Font = new Font("Microsoft YaHei UI", 13f, FontStyle.Bold),
            ForeColor = TextC,
            Location = new Point(24, 24),
        });
        Controls.Add(new Label
        {
            Text = "全能网页智能体 · 驱动 14 个网页 AI 操控电脑 · 零 API 成本",
            AutoSize = true,
            ForeColor = Dim,
            Location = new Point(26, 62),
        });

        var group = new Panel { BackColor = Panel, Location = new Point(24, 104), Size = new Size(632, 208) };
        group.Controls.Add(new Label { Text = "安装目录:", AutoSize = true, ForeColor = Dim, Location = new Point(20, 22) });
        var defDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OmniAgent");
        txtDir = new TextBox
        {
            Text = defDir,
            Location = new Point(20, 48),
            Size = new Size(472, 30),
            BackColor = Bg,
            ForeColor = TextC,
            BorderStyle = BorderStyle.FixedSingle,
        };
        group.Controls.Add(txtDir);
        btnBrowse = MakeButton("浏览...", Panel, TextC, 110, 30);
        btnBrowse.Location = new Point(500, 48);
        group.Controls.Add(btnBrowse);
        chkDesktop = new CheckBox { Text = "创建桌面快捷方式", AutoSize = true, ForeColor = TextC, Checked = true, Location = new Point(20, 96) };
        group.Controls.Add(chkDesktop);
        chkStartMenu = new CheckBox { Text = "创建开始菜单快捷方式（含卸载入口）", AutoSize = true, ForeColor = TextC, Checked = true, Location = new Point(20, 128) };
        group.Controls.Add(chkStartMenu);
        group.Controls.Add(new Label
        {
            Text = "预计占用约 50 MB。已有旧版本时将直接覆盖更新。",
            AutoSize = true,
            Font = new Font("Microsoft YaHei UI", 8.5f),
            ForeColor = Dim,
            Location = new Point(20, 164),
        });
        Controls.Add(group);

        lblStatus = new Label { Text = "请选择安装目录后点击[开始安装]", AutoSize = true, ForeColor = Dim, Location = new Point(24, 328) };
        Controls.Add(lblStatus);
        pb = new ProgressBar { Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 30, Location = new Point(24, 356), Size = new Size(632, 8), Visible = false };
        Controls.Add(pb);

        btnInstall = MakeButton("开始安装", Color.FromArgb(66, 106, 210), Color.White, 140, 40);
        btnInstall.Location = new Point(24, 386);
        btnRun = MakeButton("运行 OmniAgent", Color.FromArgb(66, 106, 210), Color.White, 160, 40);
        btnRun.Location = new Point(360, 386);
        btnRun.Visible = false;
        btnClose = MakeButton("完成", Panel, TextC, 100, 40);
        btnClose.Location = new Point(556, 386);
        btnClose.Visible = false;
        Controls.Add(btnInstall);
        Controls.Add(btnRun);
        Controls.Add(btnClose);

        btnBrowse.Click += (s, e) =>
        {
            using var dlg = new FolderBrowserDialog
            {
                Description = "选择 OmniAgent 安装目录",
                SelectedPath = Directory.Exists(txtDir.Text) ? txtDir.Text : Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            };
            if (dlg.ShowDialog() == DialogResult.OK) txtDir.Text = dlg.SelectedPath;
        };
        btnInstall.Click += (s, e) => RunInstall();
        btnRun.Click += (s, e) =>
        {
            try { System.Diagnostics.Process.Start(_installedExe, $"--basedir \"{Path.GetDirectoryName(_installedExe)}\""); } catch { }
            Close();
        };
        btnClose.Click += (s, e) => Close();
    }

    private async void RunInstall()
    {
        var dir = txtDir.Text.Trim();
        if (dir.Length == 0)
        {
            lblStatus.Text = "请先选择安装目录。";
            lblStatus.ForeColor = Warn;
            return;
        }
        try { dir = Path.GetFullPath(dir); }
        catch
        {
            lblStatus.Text = "安装目录无效，请重新选择。";
            lblStatus.ForeColor = Warn;
            return;
        }
        if (string.Equals(Path.GetPathRoot(dir), dir.TrimEnd('\\', '/') + "\\", StringComparison.OrdinalIgnoreCase))
        {
            lblStatus.Text = "请不要直接安装到磁盘根目录。";
            lblStatus.ForeColor = Warn;
            return;
        }
        lblStatus.ForeColor = Dim;
        lblStatus.Text = "正在安装，请稍候 …";
        btnInstall.Enabled = false;
        btnBrowse.Enabled = false;
        txtDir.Enabled = false;
        chkDesktop.Enabled = false;
        chkStartMenu.Enabled = false;
        pb.Visible = true;
        try
        {
            await Task.Run(() => DoInstall(dir));
            lblStatus.Text = "✅ 安装完成！";
            lblStatus.ForeColor = Success;
            btnRun.Visible = true;
            btnClose.Visible = true;
        }
        catch (Exception ex)
        {
            lblStatus.Text = "安装失败: " + ex.Message;
            lblStatus.ForeColor = Danger;
            btnInstall.Enabled = true;
            btnBrowse.Enabled = true;
            txtDir.Enabled = true;
            chkDesktop.Enabled = true;
            chkStartMenu.Enabled = true;
        }
        pb.Visible = false;
    }

    private void DoInstall(string dir)
    {
        Directory.CreateDirectory(dir);
        var exe = Path.Combine(dir, "OmniAgent.exe");
        try { System.Diagnostics.Process.Start("taskkill.exe", "/F /IM OmniAgent.exe"); } catch { }

        using var stream = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("OmniAgentBin");
        if (stream == null) throw new Exception("安装包缺少主程序资源");
        using var ms = new MemoryStream();
        stream.CopyTo(ms);
        File.WriteAllBytes(exe, ms.ToArray());
        _installedExe = exe;

        var t = Type.GetTypeFromProgID("WScript.Shell");
        if (t == null) throw new Exception("系统缺少 WScript.Shell 组件");
        dynamic ws = Activator.CreateInstance(t);

        if (chkDesktop.Checked)
        {
            var desk = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            dynamic sc = ws.CreateShortcut(Path.Combine(desk, "OmniAgent.lnk"));
            sc.TargetPath = exe;
            sc.WorkingDirectory = dir;
            sc.Arguments = "--basedir \"" + dir + "\"";
            sc.IconLocation = exe + ",0";
            sc.Description = "OmniAgent 全能网页智能体";
            sc.Save();
        }
        if (chkStartMenu.Checked)
        {
            var programs = Environment.GetFolderPath(Environment.SpecialFolder.Programs);
            var folder = Path.Combine(programs, "OmniAgent");
            Directory.CreateDirectory(folder);
            dynamic sc = ws.CreateShortcut(Path.Combine(folder, "OmniAgent.lnk"));
            sc.TargetPath = exe;
            sc.WorkingDirectory = dir;
            sc.Arguments = "--basedir \"" + dir + "\"";
            sc.IconLocation = exe + ",0";
            sc.Description = "OmniAgent 全能网页智能体";
            sc.Save();

            var bat = Path.Combine(dir, "uninstall.bat");
            File.WriteAllText(bat, MakeUninstallBat(dir), System.Text.Encoding.ASCII);
            dynamic u = ws.CreateShortcut(Path.Combine(folder, "卸载 OmniAgent.lnk"));
            u.TargetPath = bat;
            u.WorkingDirectory = dir;
            u.IconLocation = "shell32.dll,27";
            u.Description = "卸载 OmniAgent";
            u.Save();
        }
    }

    /// <summary>静默安装（--silent 模式，供自动化测试）。</summary>
    public void InstallSilent(string dir)
    {
        try
        {
            chkDesktop = new CheckBox { Checked = true };
            chkStartMenu = new CheckBox { Checked = true };
            DoInstall(dir);
            File.WriteAllText(Path.Combine(dir, "install_success.txt"), "ok " + DateTime.Now.ToString("s"));
        }
        catch (Exception ex)
        {
            File.WriteAllText(Path.Combine(Path.GetTempPath(), "omniagent_setup_error.txt"), ex.ToString());
        }
    }

    private static string MakeUninstallBat(string dir)
    {
        var d = dir.Replace("%", "%%");
        return "@echo off\r\n" +
               "title OmniAgent Uninstall\r\n" +
               "taskkill /F /IM OmniAgent.exe >nul 2>&1\r\n" +
               "ping -n 2 127.0.0.1 >nul\r\n" +
               "if exist \"%USERPROFILE%\\Desktop\\OmniAgent.lnk\" del /Q \"%USERPROFILE%\\Desktop\\OmniAgent.lnk\"\r\n" +
               "if exist \"%ProgramData%\\Microsoft\\Windows\\Start Menu\\Programs\\OmniAgent\" rmdir /S /Q \"%ProgramData%\\Microsoft\\Windows\\Start Menu\\Programs\\OmniAgent\"\r\n" +
               "cd /d \"%TEMP%\"\r\n" +
               "rmdir /S /Q \"" + d + "\"\r\n" +
               "echo Uninstall finished. Press any key to exit.\r\n" +
               "pause >nul\r\n";
    }
}
