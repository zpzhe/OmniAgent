using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;
using OmniAgent.Core;

namespace OmniAgent.Tools;

/// <summary>
/// 电脑工具集：AI 通过工具标记调用这些能力（命令执行、截图、鼠标键盘、窗口、文件、剪贴板、HTTP）。
/// 全部基于 .NET BCL + Win32 P/Invoke，无第三方依赖。
/// </summary>
public class ToolExecutor
{
    public string WorkDir { get; }
    private int _seq;
    private readonly HttpClient _http;

    public ToolExecutor(string workDir)
    {
        WorkDir = workDir;
        Directory.CreateDirectory(workDir);
        _http = new HttpClient(new HttpClientHandler())
        {
            Timeout = TimeSpan.FromSeconds(120),
        };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
    }

    // ================= 截图 =================

    /// <summary>截图。region 全 0 表示全屏（虚拟屏幕）。返回 PNG 字节。</summary>
    public byte[] Screenshot(int x, int y, int w, int h)
    {
        int sx = x, sy = y, sw = w, sh = h;
        if (sw <= 0 || sh <= 0)
        {
            sx = Win32.GetSystemMetrics(Win32.SM_XVIRTUALSCREEN);
            sy = Win32.GetSystemMetrics(Win32.SM_YVIRTUALSCREEN);
            sw = Win32.GetSystemMetrics(Win32.SM_CXVIRTUALSCREEN);
            sh = Win32.GetSystemMetrics(Win32.SM_CYVIRTUALSCREEN);
        }
        using var bmp = new Bitmap(sw, sh);
        using (var g = Graphics.FromImage(bmp))
        {
            g.CopyFromScreen(sx, sy, 0, 0, new Size(sw, sh), CopyPixelOperation.SourceCopy);
        }
        using var ms = new MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        return ms.ToArray();
    }

    public string SaveScreenshot(int x, int y, int w, int h)
    {
        var bytes = Screenshot(x, y, w, h);
        var path = Path.Combine(WorkDir, $"shot_{++_seq}_{DateTime.Now:HHmmss}.png");
        File.WriteAllBytes(path, bytes);
        return path;
    }

    // ================= 命令执行 =================

    /// <summary>执行 PowerShell 脚本（写临时 .ps1，UTF8 BOM，捕获输出，超时强杀）。</summary>
    public async Task<string> ExecCommandAsync(string script, int timeoutMs = 120000)
    {
        var seq = ++_seq;
        var codeFile = Path.Combine(WorkDir, $"code_{seq}.txt");
        var file = Path.Combine(WorkDir, $"cmd_{seq}.ps1");
        File.WriteAllText(codeFile, script, new UTF8Encoding(true));
        // 包装脚本：先把输出编码切到 UTF-8，再经 Invoke-Expression 执行用户代码，
        // 这样即使代码有解析错误也能以 UTF-8 输出（解析错误发生在运行时而非整文件解析期）。
        var wrapper =
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\n" +
            "$ErrorActionPreference = 'Continue'\n" +
            $"$codeFile = '{codeFile.Replace("'", "''")}'\n" +
            "try {\n" +
            "  $code = Get-Content -LiteralPath $codeFile -Raw -Encoding UTF8\n" +
            "  Invoke-Expression $code\n" +
            "} catch {\n" +
            "  Write-Output ('[命令异常] ' + $_.Exception.Message)\n" +
            "}";
        File.WriteAllText(file, wrapper, new UTF8Encoding(true));

        var psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"{file}\"",
            WorkingDirectory = WorkDir,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
            CreateNoWindow = true,
        };
        var sb = new StringBuilder();
        using var p = new Process { StartInfo = psi };
        p.OutputDataReceived += (s, e) => { if (e.Data != null) sb.AppendLine(e.Data); };
        p.ErrorDataReceived += (s, e) => { if (e.Data != null) sb.AppendLine("[ERR] " + e.Data); };
        try
        {
            p.Start();
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();
            using var cts = new CancellationTokenSource(timeoutMs);
            await p.WaitForExitAsync(cts.Token);
        }
        catch (OperationCanceledException)
        {
            try { Process.Start("taskkill.exe", $"/F /T /PID {p.Id}"); } catch { }
            sb.AppendLine($"[超时] 命令执行超过 {timeoutMs / 1000} 秒，已强制终止。");
        }
        catch (Exception ex)
        {
            sb.AppendLine("[启动失败] " + ex.Message);
        }
        var outText = sb.ToString().TrimEnd();
        var outFile = Path.Combine(WorkDir, $"cmd_{seq}_out.txt");
        File.WriteAllText(outFile, outText, new UTF8Encoding(false));
        const int cap = 12000;
        var shown = outText;
        if (shown.Length > cap)
            shown = shown.Substring(0, cap) + $"\n...（输出被截断，共 {outText.Length} 字符。完整输出已保存，可用 读取文件_star({outFile})_读取文件_end 查看）";
        if (shown.Length == 0) shown = "(无输出)";
        return shown;
    }

    /// <summary>运行任意程序（等待完成并捕获输出）。</summary>
    public async Task<string> ExecProgramAsync(string exe, string args, int timeoutMs = 60000)
    {
        var psi = new ProcessStartInfo
        {
            FileName = exe,
            Arguments = args ?? "",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
            CreateNoWindow = true,
        };
        var sb = new StringBuilder();
        using var p = new Process { StartInfo = psi };
        p.OutputDataReceived += (s, e) => { if (e.Data != null) sb.AppendLine(e.Data); };
        p.ErrorDataReceived += (s, e) => { if (e.Data != null) sb.AppendLine("[ERR] " + e.Data); };
        try
        {
            p.Start();
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();
            using var cts = new CancellationTokenSource(timeoutMs);
            await p.WaitForExitAsync(cts.Token);
        }
        catch (OperationCanceledException)
        {
            try { Process.Start("taskkill.exe", $"/F /T /PID {p.Id}"); } catch { }
            sb.AppendLine($"[超时] 程序执行超过 {timeoutMs / 1000} 秒，已强制终止。");
        }
        catch (Exception ex)
        {
            return "[启动失败] " + ex.Message;
        }
        var t = sb.ToString().TrimEnd();
        if (t.Length == 0) t = "(无输出)";
        if (t.Length > 12000) t = t.Substring(0, 12000) + "\n...（截断）";
        return t;
    }

    // ================= 鼠标键盘 =================

    public string ScreenInfo()
    {
        int x = Win32.GetSystemMetrics(Win32.SM_XVIRTUALSCREEN);
        int y = Win32.GetSystemMetrics(Win32.SM_YVIRTUALSCREEN);
        int w = Win32.GetSystemMetrics(Win32.SM_CXVIRTUALSCREEN);
        int h = Win32.GetSystemMetrics(Win32.SM_CYVIRTUALSCREEN);
        Win32.GetCursorPos(out var pt);
        return $"屏幕: 左上({x},{y}) 宽{w} 高{h}；鼠标当前: ({pt.X},{pt.Y})";
    }

    public string MouseMove(int x, int y)
    {
        if (!Win32.SetCursorPos(x, y)) return "[失败] SetCursorPos";
        return $"鼠标已移动到 ({x},{y})";
    }

    public string MouseClick(int x, int y, string button = "左键", int clicks = 1, int moveFirst = 1)
    {
        if (moveFirst != 0) Win32.SetCursorPos(x, y);
        uint down, up;
        switch (button)
        {
            case "右键": down = Win32.MOUSEEVENTF_RIGHTDOWN; up = Win32.MOUSEEVENTF_RIGHTUP; break;
            case "中键": down = Win32.MOUSEEVENTF_MIDDLEDOWN; up = Win32.MOUSEEVENTF_MIDDLEUP; break;
            default: down = Win32.MOUSEEVENTF_LEFTDOWN; up = Win32.MOUSEEVENTF_LEFTUP; break;
        }
        for (int i = 0; i < clicks; i++)
        {
            SendMouse(down, 0);
            SendMouse(up, 0);
            if (i < clicks - 1) Thread.Sleep(80);
        }
        return $"已在 ({x},{y}) {button}点击 {clicks} 次";
    }

    public string MouseScroll(int amount, int x = int.MinValue, int y = int.MinValue)
    {
        if (x != int.MinValue && y != int.MinValue) Win32.SetCursorPos(x, y);
        SendMouse(Win32.MOUSEEVENTF_WHEEL, (uint)(amount * 120));
        return $"已滚动 {amount} 格";
    }

    public string MouseDrag(int x1, int y1, int x2, int y2, int steps = 30, int ms = 400)
    {
        Win32.SetCursorPos(x1, y1);
        SendMouse(Win32.MOUSEEVENTF_LEFTDOWN, 0);
        Thread.Sleep(60);
        for (int i = 1; i <= steps; i++)
        {
            var cx = x1 + (x2 - x1) * i / steps;
            var cy = y1 + (y2 - y1) * i / steps;
            Win32.SetCursorPos(cx, cy);
            Thread.Sleep(ms / steps);
        }
        SendMouse(Win32.MOUSEEVENTF_LEFTUP, 0);
        return $"已从 ({x1},{y1}) 拖拽到 ({x2},{y2})";
    }

    private static void SendMouse(uint flags, uint data)
    {
        var input = new Win32.INPUT
        {
            type = Win32.INPUT_MOUSE,
            u = { mi = new Win32.MOUSEINPUT { dwFlags = flags, mouseData = data, time = 0, dwExtraInfo = IntPtr.Zero } },
        };
        Win32.SendInput(1, new[] { input }, Marshal.SizeOf<Win32.INPUT>());
    }

    public string KeyTap(string combo)
    {
        var keys = ParseKeys(combo);
        if (keys.Count == 0) return "[失败] 无法解析按键: " + combo;
        var inputs = new List<Win32.INPUT>();
        foreach (var vk in keys)
            inputs.Add(KeyInput(vk, false));
        for (int i = keys.Count - 1; i >= 0; i--)
            inputs.Add(KeyInput(keys[i], true));
        Win32.SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf<Win32.INPUT>());
        return $"已按下按键: {combo}";
    }

    public string TypeText(string text)
    {
        if (string.IsNullOrEmpty(text)) return "(空文本)";
        SetClipboard(text);
        Thread.Sleep(50);
        KeyTap("ctrl+v");
        return $"已通过剪贴板粘贴输入 {text.Length} 个字符";
    }

    private static Win32.INPUT KeyInput(ushort vk, bool up)
    {
        return new Win32.INPUT
        {
            type = Win32.INPUT_KEYBOARD,
            u = { ki = new Win32.KEYBDINPUT { wVk = vk, wScan = 0, dwFlags = up ? Win32.KEYEVENTF_KEYUP : 0, time = 0, dwExtraInfo = IntPtr.Zero } },
        };
    }

    private static readonly Dictionary<string, ushort> VkMap = new(StringComparer.OrdinalIgnoreCase);

    static ToolExecutor()
    {
        void Add(string name, ushort vk) => VkMap[name] = vk;
        Add("enter", 0x0D); Add("return", 0x0D); Add("esc", 0x1B); Add("escape", 0x1B);
        Add("tab", 0x09); Add("space", 0x20); Add("backspace", 0x08); Add("delete", 0x2E);
        Add("del", 0x2E); Add("insert", 0x2D); Add("home", 0x24); Add("end", 0x23);
        Add("pageup", 0x21); Add("pagedown", 0x22); Add("up", 0x26); Add("down", 0x28);
        Add("left", 0x25); Add("right", 0x27); Add("ctrl", 0x11); Add("control", 0x11);
        Add("alt", 0x12); Add("shift", 0x10); Add("win", 0x5B); Add("lwin", 0x5B);
        Add("rwin", 0x5C); Add("menu", 0x12); Add("capslock", 0x14); Add("numlock", 0x90);
        for (int i = 0; i < 26; i++) { Add(((char)('a' + i)).ToString(), (ushort)(0x41 + i)); Add(((char)('A' + i)).ToString(), (ushort)(0x41 + i)); }
        for (int i = 0; i <= 9; i++) Add(i.ToString(), (ushort)(0x30 + i));
        for (int i = 1; i <= 24; i++) Add("f" + i, (ushort)(0x6F + i));
        Add(";", 0xBA); Add("=", 0xBB); Add(",", 0xBC); Add("-", 0xBD); Add(".", 0xBE); Add("/", 0xBF); Add("`", 0xC0);
        Add("[", 0xDB); Add("\\", 0xDC); Add("]", 0xDD); Add("'", 0xDE);
    }

    private static List<ushort> ParseKeys(string combo)
    {
        var list = new List<ushort>();
        foreach (var part in combo.Split('+'))
        {
            var p = part.Trim();
            if (p.Length == 0) continue;
            if (VkMap.TryGetValue(p, out var vk)) { list.Add(vk); continue; }
            if (p.Length == 1) { list.Add((ushort)(char.ToUpper(p[0]))); continue; }
        }
        return list;
    }

    // ================= 剪贴板 =================

    public string GetClipboard()
    {
        if (!Win32.OpenClipboard(IntPtr.Zero)) return "[失败] 剪贴板被占用";
        try
        {
            var h = Win32.GetClipboardData(Win32.CF_UNICODETEXT);
            if (h == IntPtr.Zero) return "(剪贴板无文本)";
            var ptr = Win32.GlobalLock(h);
            if (ptr == IntPtr.Zero) return "(锁定失败)";
            try { return Marshal.PtrToStringUni(ptr); }
            finally { Win32.GlobalUnlock(h); }
        }
        finally { Win32.CloseClipboard(); }
    }

    public string SetClipboard(string text)
    {
        var bytes = Encoding.Unicode.GetBytes(text + "\0");
        var hMem = Win32.GlobalAlloc(Win32.GMEM_MOVEABLE, (UIntPtr)bytes.Length);
        if (hMem == IntPtr.Zero) return "[失败] GlobalAlloc";
        var ptr = Win32.GlobalLock(hMem);
        Marshal.Copy(bytes, 0, ptr, bytes.Length);
        Win32.GlobalUnlock(hMem);
        if (!Win32.OpenClipboard(IntPtr.Zero)) return "[失败] OpenClipboard";
        try
        {
            Win32.EmptyClipboard();
            Win32.SetClipboardData(Win32.CF_UNICODETEXT, hMem);
        }
        finally { Win32.CloseClipboard(); }
        return $"已写入剪贴板 {text.Length} 字符";
    }

    // ================= 窗口 =================

    public List<string> GetWindowList()
    {
        var list = new List<string>();
        Win32.EnumWindows((h, l) =>
        {
            if (!Win32.IsWindowVisible(h)) return true;
            var title = Win32.GetWindowTitle(h);
            if (title.Length == 0) return true;
            if (h == (IntPtr)l) return true;
            Win32.GetWindowThreadProcessId(h, out var pid);
            Win32.GetWindowRect(h, out var r);
            var cls = Win32.GetWindowClass(h);
            var icon = Win32.IsIconic(h) ? "最小化" : "正常";
            list.Add($"{h.ToInt64()}|{title}|{cls}|pid={pid}|{icon}|({r.Left},{r.Top},{r.Right},{r.Bottom})");
            return true;
        }, IntPtr.Zero);
        return list;
    }

    private IntPtr FindWindow(string hwndOrTitle)
    {
        if (long.TryParse(hwndOrTitle, out var num) && num > 0) return new IntPtr(num);
        var found = IntPtr.Zero;
        Win32.EnumWindows((h, l) =>
        {
            var t = Win32.GetWindowTitle(h);
            if (t.Contains(hwndOrTitle, StringComparison.OrdinalIgnoreCase)) { found = h; return false; }
            return true;
        }, IntPtr.Zero);
        return found;
    }

    public string WindowAction(string hwndOrTitle, string action)
    {
        var h = FindWindow(hwndOrTitle);
        if (h == IntPtr.Zero) return $"[失败] 未找到窗口: {hwndOrTitle}";
        switch (action)
        {
            case "前台": Win32.SetForegroundWindow(h); return "已切到前台";
            case "最小化": Win32.ShowWindow(h, (int)Win32.SW_SHOWMINIMIZED); return "已最小化";
            case "最大化": Win32.ShowWindow(h, (int)Win32.SW_SHOWMAXIMIZED); return "已最大化";
            case "还原": Win32.ShowWindow(h, (int)Win32.SW_SHOWNORMAL); return "已还原";
            case "关闭": Win32.PostMessage(h, Win32.WM_CLOSE, IntPtr.Zero, IntPtr.Zero); return "已发送关闭消息";
            case "置顶":
                Win32.SetWindowPos(h, Win32.HWND_TOPMOST, 0, 0, 0, 0, Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_SHOWWINDOW);
                return "已置顶";
            case "取消置顶":
                Win32.SetWindowPos(h, Win32.HWND_NOTOPMOST, 0, 0, 0, 0, Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_SHOWWINDOW);
                return "已取消置顶";
            default: return "[失败] 未知操作: " + action;
        }
    }

    // ================= 文件 =================

    public string ReadFile(string path, int maxChars = 60000)
    {
        if (!File.Exists(path)) return "[失败] 文件不存在: " + path;
        var bytes = File.ReadAllBytes(path);
        string text;
        if (bytes.Length >= 2 && ((bytes[0] == 0xFF && bytes[1] == 0xFE) || (bytes[0] == 0xFE && bytes[1] == 0xFF)))
            text = bytes[0] == 0xFF ? Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2) : Encoding.BigEndianUnicode.GetString(bytes, 2, bytes.Length - 2);
        else
        {
            try { text = new UTF8Encoding(false, true).GetString(bytes); }
            catch { text = Encoding.GetEncoding(936).GetString(bytes); }
        }
        if (text.Length > maxChars) text = text.Substring(0, maxChars) + $"\n...（截断，文件共 {text.Length} 字符）";
        return text;
    }

    public string WriteFile(string path, string content, string mode = "覆盖")
    {
        if (!Path.IsPathRooted(path)) path = Path.Combine(WorkDir, path);
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        if (mode == "追加")
            File.AppendAllText(path, content, new UTF8Encoding(false));
        else
            File.WriteAllText(path, content, new UTF8Encoding(false));
        return $"已写入 {path}（{content.Length} 字符）";
    }

    public string ListDir(string path, int maxItems = 200)
    {
        if (!Directory.Exists(path)) return "[失败] 目录不存在: " + path;
        var sb = new StringBuilder();
        var entries = new DirectoryInfo(path).GetFileSystemInfos().Take(maxItems).ToList();
        sb.AppendLine($"共 {entries.Count} 项:");
        foreach (var e in entries)
        {
            if (e is DirectoryInfo) sb.AppendLine($"[目录] {e.Name}");
            else sb.AppendLine($"[文件] {e.Name} ({((FileInfo)e).Length} 字节)");
        }
        return sb.ToString().TrimEnd();
    }

    public string FileExists(string path) => File.Exists(path) ? "存在" : Directory.Exists(path) ? "存在(目录)" : "不存在";

    // ================= HTTP =================

    public async Task<string> HttpGetAsync(string url, int maxChars = 60000)
    {
        try
        {
            using var resp = await _http.GetAsync(url);
            var body = await resp.Content.ReadAsStringAsync();
            var info = $"HTTP {(int)resp.StatusCode} {resp.StatusCode}，内容长度 {body.Length} 字符\n";
            if (body.Length > maxChars) body = body.Substring(0, maxChars) + "\n...（截断）";
            return info + body;
        }
        catch (Exception ex) { return "[失败] " + ex.Message; }
    }

    public async Task<string> DownloadFileAsync(string url, string saveTo)
    {
        try
        {
            if (!Path.IsPathRooted(saveTo)) saveTo = Path.Combine(WorkDir, saveTo);
            Directory.CreateDirectory(Path.GetDirectoryName(saveTo));
            var bytes = await _http.GetByteArrayAsync(url);
            File.WriteAllBytes(saveTo, bytes);
            return $"已下载 {bytes.Length} 字节到 {saveTo}";
        }
        catch (Exception ex) { return "[失败] " + ex.Message; }
    }

    // ================= 其他 =================

    public string Wait(int ms)
    {
        ms = Compat.Clamp(ms, 10, 60000);
        Thread.Sleep(ms);
        return $"已等待 {ms} 毫秒";
    }

    public string GetTime() => $"当前时间: {DateTime.Now:yyyy-MM-dd HH:mm:ss}（系统时区 {TimeZoneInfo.Local.DisplayName}）";
}
